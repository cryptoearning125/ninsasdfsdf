import * as React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronDown, Loader, CheckCircle, AlertCircle, XCircle, Trash2 } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import type { Order, Trade, UserOrder, NewOrderData, UpdateOrderData } from '../types.ts';
import { useTheme } from '../contexts/ThemeContext.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';

// Mock data
const chartData = Array.from({ length: 50 }, (_, i) => ({
  name: `T-${50-i}`,
  price: 68000 + Math.random() * 2000 - 1000 + i * 20,
}));

const generateOrderBook = (count: number, startPrice: number, isBids: boolean) => {
    return Array.from({length: count}, (_, i) => {
        const price = startPrice + (isBids ? -i : i) * Math.random() * 10;
        const amount = Math.random() * 2;
        return { price, amount, total: price * amount };
    }).sort((a,b) => isBids ? b.price - a.price : a.price - b.price);
};
const mockBids: Order[] = generateOrderBook(20, 69450, true);
const mockAsks: Order[] = generateOrderBook(20, 69500, false);

const mockTrades: Trade[] = Array.from({length: 30}, (_, i) => ({
    id: `trade-${i}`,
    time: new Date(Date.now() - i * 15000).toLocaleTimeString(),
    price: 69480 + Math.random() * 40 - 20,
    amount: Math.random() * 0.5,
    type: Math.random() > 0.5 ? 'buy' : 'sell'
}));

const TradingScreen = () => {
    const { pair: paramPair } = useParams<{ pair?: string }>();
    const navigate = useNavigate();
    const { theme } = useTheme();
    const [activePair, setActivePair] = React.useState(paramPair || 'BTC-USDT');
    const { user } = useAuth();
    const [timeframe, setTimeframe] = React.useState('1H');
    
    React.useEffect(() => {
        if(paramPair) setActivePair(paramPair);
    }, [paramPair]);

    const chartColors = {
        grid: theme === 'dark' ? '#374151' : '#e5e7eb',
        axis: theme === 'dark' ? '#9ca3af' : '#6b7280',
        tooltipBg: theme === 'dark' ? '#1f2937' : '#ffffff',
        tooltipBorder: theme === 'dark' ? '#374151' : '#e5e7eb',
        text: theme === 'dark' ? '#f8fafc' : '#1e293b'
    };

    const OrderBook = ({ bids, asks }: { bids: Order[]; asks: Order[]; }) => (
        <div className="bg-white dark:bg-slate-950 rounded-lg p-3 h-full flex flex-col border border-gray-200 dark:border-transparent">
            <h3 className="text-lg font-bold mb-2">Order Book</h3>
            <div className="grid grid-cols-2 gap-4 text-xs mb-1 text-gray-500 dark:text-gray-400">
                <div>Price (USDT)</div>
                <div className="text-right">Amount (BTC)</div>
            </div>
            <div className="flex-grow overflow-y-auto">
                {/* Asks */}
                <div>
                    {asks.slice(0, 8).reverse().map((order, i) => (
                        <div key={i} className="relative flex justify-between items-center h-6 text-xs hover:bg-gray-100 dark:hover:bg-slate-700/50">
                            <div className="absolute top-0 left-0 h-full bg-red-500/10" style={{ width: `${Math.random() * 80 + 10}%` }}></div>
                            <span className="z-10 text-red-500 dark:text-red-400">{order.price.toFixed(2)}</span>
                            <span className="z-10">{order.amount.toFixed(4)}</span>
                        </div>
                    ))}
                </div>
                 <div className="text-lg font-bold text-center py-2 text-green-500 dark:text-green-400">69,500.12</div>
                {/* Bids */}
                <div>
                    {bids.slice(0, 8).map((order, i) => (
                         <div key={i} className="relative flex justify-between items-center h-6 text-xs hover:bg-gray-100 dark:hover:bg-slate-700/50">
                            <div className="absolute top-0 left-0 h-full bg-green-500/10" style={{ width: `${Math.random() * 80 + 10}%` }}></div>
                            <span className="z-10 text-green-500 dark:text-green-400">{order.price.toFixed(2)}</span>
                            <span className="z-10">{order.amount.toFixed(4)}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
    
    const RecentTrades = ({ trades }: { trades: Trade[] }) => (
        <div className="bg-white dark:bg-slate-950 rounded-lg p-3 h-full flex flex-col border border-gray-200 dark:border-transparent">
            <h3 className="text-lg font-bold mb-2">Recent Trades</h3>
            <div className="grid grid-cols-3 gap-2 text-xs text-gray-500 dark:text-gray-400 mb-1">
                <span>Time</span>
                <span className="text-right">Price (USDT)</span>
                <span className="text-right">Amount (BTC)</span>
            </div>
            <div className="flex-grow overflow-y-auto">
                {trades.map(trade => (
                    <div key={trade.id} className={`grid grid-cols-3 gap-2 text-xs py-1 ${trade.type === 'buy' ? 'text-green-500 dark:text-green-400' : 'text-red-500 dark:text-red-400'}`}>
                        <span className="text-slate-700 dark:text-gray-400">{trade.time}</span>
                        <span className="text-right">{trade.price.toFixed(2)}</span>
                        <span className="text-right">{trade.amount.toFixed(4)}</span>
                    </div>
                ))}
            </div>
        </div>
    );
    
    const OrderForm = () => {
        const { user, placeOrder } = useAuth();
        const [tradeType, setTradeType] = React.useState<'buy' | 'sell'>('buy');
        const [orderType, setOrderType] = React.useState<'limit' | 'market' | 'stop'>('limit');
        const [price, setPrice] = React.useState('69500.00');
        const [amount, setAmount] = React.useState('');
        const [submitting, setSubmitting] = React.useState(false);
        const [status, setStatus] = React.useState<{type: 'success' | 'error', message: string} | null>(null);

        const handleSubmit = async (e: React.FormEvent) => {
            e.preventDefault();
            if (!amount || Number(amount) <= 0) {
                setStatus({ type: 'error', message: 'Please enter a valid amount.'});
                return;
            }
            setSubmitting(true);
            setStatus(null);
            try {
                const orderData: NewOrderData = {
                    pair: activePair,
                    type: tradeType,
                    orderType,
                    price: orderType === 'market' ? 0 : parseFloat(price),
                    amount: parseFloat(amount),
                };
                await placeOrder(orderData);
                setStatus({ type: 'success', message: 'Order placed successfully!' });
                setAmount('');
            } catch (err) {
                setStatus({type: 'error', message: err instanceof Error ? err.message : 'Failed to place order.'});
            } finally {
                setSubmitting(false);
                setTimeout(() => setStatus(null), 4000);
            }
        };
        
        const total = (Number(price) || 0) * (Number(amount) || 0);

        return (
            <form onSubmit={handleSubmit} className="bg-white dark:bg-slate-950 rounded-lg p-4 border border-gray-200 dark:border-transparent">
                <div className="flex mb-4">
                    <button type="button"
                        className={`w-1/2 py-2 text-center font-semibold rounded-l-lg transition-colors ${tradeType === 'buy' ? 'bg-green-600 text-white' : 'bg-gray-200 dark:bg-slate-700 hover:bg-gray-300 dark:hover:bg-slate-600'}`}
                        onClick={() => setTradeType('buy')}>
                        Buy
                    </button>
                    <button type="button"
                        className={`w-1/2 py-2 text-center font-semibold rounded-r-lg transition-colors ${tradeType === 'sell' ? 'bg-red-600 text-white' : 'bg-gray-200 dark:bg-slate-700 hover:bg-gray-300 dark:hover:bg-slate-600'}`}
                        onClick={() => setTradeType('sell')}>
                        Sell
                    </button>
                </div>
                <div className="flex space-x-2 text-sm mb-4">
                    {['Limit', 'Market', 'Stop'].map(type => (
                        <button type="button" key={type} onClick={() => setOrderType(type.toLowerCase() as any)}
                            className={`px-3 py-1 rounded ${orderType === type.toLowerCase() ? 'text-slate-900 dark:text-white' : 'text-gray-500 dark:text-gray-400 hover:text-slate-900 dark:hover:text-white'}`}>
                            {type}
                        </button>
                    ))}
                </div>
                <div className="space-y-4">
                    {orderType !== 'market' && (
                         <div>
                            <label className="text-xs text-gray-500 dark:text-gray-400">Price (USDT)</label>
                            <input type="number" value={price} onChange={e => setPrice(e.target.value)} className="w-full bg-gray-100 dark:bg-slate-900 border border-gray-300 dark:border-slate-700 rounded p-2 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-500" />
                        </div>
                    )}
                    <div>
                        <label className="text-xs text-gray-500 dark:text-gray-400">Amount (BTC)</label>
                        <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00000" className="w-full bg-gray-100 dark:bg-slate-900 border border-gray-300 dark:border-slate-700 rounded p-2 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-500" />
                    </div>
                    <div>
                         <p className="text-xs text-gray-500 dark:text-gray-400 flex justify-between"><span>Available:</span> <span>${user?.portfolio.balance.toLocaleString() || '0.00'} USDT</span></p>
                         <p className="text-xs text-gray-500 dark:text-gray-400 flex justify-between mt-1"><span>Total:</span> <span>{total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT</span></p>
                    </div>
                    {status && (
                        <div className={`flex items-center text-sm p-2 rounded-md ${status.type === 'success' ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}>
                            {status.type === 'success' ? <CheckCircle size={16} className="mr-2"/> : <AlertCircle size={16} className="mr-2"/>}
                            {status.message}
                        </div>
                    )}
                     <button type="submit" disabled={submitting} className={`w-full py-3 rounded-lg font-bold text-white transition-colors flex justify-center items-center ${tradeType === 'buy' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'} disabled:bg-slate-500 dark:disabled:bg-slate-700`}>
                        {submitting ? <Loader className="animate-spin"/> : `${tradeType === 'buy' ? 'Buy BTC' : 'Sell BTC'}`}
                    </button>
                </div>
            </form>
        );
    }
    
    const OrdersAndHistory = () => {
        const [activeTab, setActiveTab] = React.useState('open');
        const { user, cancelOrder } = useAuth();
        const [cancellingId, setCancellingId] = React.useState<string|null>(null);

        const handleCancel = async (orderId: string) => {
            setCancellingId(orderId);
            try {
                await cancelOrder(orderId);
            } catch(e) {
                console.error("Failed to cancel order", e);
            } finally {
                setCancellingId(null);
            }
        };

        const StatusBadge = ({ status } : { status: UserOrder['status']}) => {
            const styles = {
                open: 'bg-blue-500/20 text-blue-400',
                filled: 'bg-green-500/20 text-green-400',
                cancelled: 'bg-red-500/20 text-red-400',
                'partially-filled': 'bg-yellow-500/20 text-yellow-400',
            }
            return <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${styles[status]}`}>{status}</span>
        }
        
        const OrderRow = ({ order, isHistory=false }: { order: UserOrder; isHistory?: boolean }) => (
             <div className={`grid grid-cols-5 gap-2 text-xs py-3 px-4 border-b border-gray-100 dark:border-zinc-800 last:border-0`}>
                <div>
                    <p className="font-semibold text-slate-900 dark:text-white">{order.pair}</p>
                    <p className={`capitalize font-bold ${order.type === 'buy' ? 'text-green-500' : 'text-red-500'}`}>{order.type}</p>
                </div>
                <div className="text-gray-500 dark:text-gray-300">
                    <p>{order.price.toFixed(2)}</p>
                    <p className="text-gray-400 dark:text-gray-500 capitalize">{order.orderType}</p>
                </div>
                <div className="text-gray-500 dark:text-gray-300">{order.amount.toFixed(4)}</div>
                <div className="text-gray-500 dark:text-gray-300">
                    {isHistory ? <StatusBadge status={order.status} /> : new Date(order.createdAt).toLocaleDateString()}
                </div>
                <div className="flex justify-end items-center">
                    {!isHistory && (
                        <button disabled={cancellingId === order.id} onClick={() => handleCancel(order.id)} className="p-1 text-red-500 hover:bg-red-500/10 rounded-full disabled:opacity-50">
                            {cancellingId === order.id ? <Loader size={16} className="animate-spin"/> : <XCircle size={16} />}
                        </button>
                    )}
                </div>
            </div>
        );

        return (
            <div className="bg-white dark:bg-slate-950 rounded-lg border border-gray-200 dark:border-transparent">
                <div className="flex border-b border-gray-100 dark:border-zinc-800">
                    <button onClick={() => setActiveTab('open')} className={`px-4 py-3 font-semibold ${activeTab === 'open' ? 'text-purple-500 border-b-2 border-purple-500' : 'text-gray-500'}`}>Open Orders ({user?.openOrders?.length || 0})</button>
                    <button onClick={() => setActiveTab('history')} className={`px-4 py-3 font-semibold ${activeTab === 'history' ? 'text-purple-500 border-b-2 border-purple-500' : 'text-gray-500'}`}>Order History</button>
                </div>
                <div className="grid grid-cols-5 gap-2 text-xs text-gray-400 dark:text-gray-500 font-bold p-4">
                    <span>Pair/Type</span>
                    <span>Price/Order</span>
                    <span>Amount</span>
                    <span>{activeTab === 'open' ? 'Date' : 'Status'}</span>
                    <span className="text-right">Action</span>
                </div>
                <div className="max-h-64 overflow-y-auto">
                    {activeTab === 'open' && (user?.openOrders?.length ? user.openOrders.map(o => <OrderRow key={o.id} order={o} />) : <p className="text-center text-gray-500 p-8">No open orders.</p>)}
                    {activeTab === 'history' && (user?.orderHistory?.length ? user.orderHistory.map(o => <OrderRow key={o.id} order={o} isHistory />) : <p className="text-center text-gray-500 p-8">No order history.</p>)}
                </div>
            </div>
        )
    }

    const TimeframeControl = () => {
        const timeframes = ['15m', '1H', '4H', '1D'];
        return (
            <div className="flex items-center space-x-2 bg-gray-100 dark:bg-slate-800/50 p-1 rounded-md">
                {timeframes.map(tf => (
                    <button 
                        key={tf} 
                        onClick={() => setTimeframe(tf)}
                        className={`px-3 py-1 text-sm font-semibold rounded-md transition-colors ${timeframe === tf ? 'bg-white dark:bg-slate-700 text-purple-500' : 'text-gray-500 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-slate-700/50'}`}
                    >
                        {tf}
                    </button>
                ))}
            </div>
        )
    }

    return (
        <div className="p-2 lg:p-4 max-w-screen-2xl mx-auto text-slate-900 dark:text-white">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                {/* Main Content: Chart and Order Form */}
                <div className="lg:col-span-9 space-y-4">
                    {/* Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-white dark:bg-slate-950 rounded-lg border border-gray-200 dark:border-transparent">
                        <div className="flex items-center space-x-4">
                            <div className="relative group">
                                <button className="flex items-center text-2xl font-bold">
                                    {activePair.replace('-', '/')} <ChevronDown size={20} className="ml-2 group-hover:text-purple-400" />
                                </button>
                                {/* Dropdown would go here */}
                            </div>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-2 mt-4 sm:mt-0 text-sm">
                            <div>
                                <p className="text-gray-500 dark:text-gray-400">Last Price</p>
                                <p className="font-semibold text-green-500 dark:text-green-400">69,500.12</p>
                            </div>
                            <div>
                                <p className="text-gray-500 dark:text-gray-400">24h Change</p>
                                <p className="font-semibold text-green-500 dark:text-green-400">+1,230.45 (+1.82%)</p>
                            </div>
                            <div>
                                <p className="text-gray-500 dark:text-gray-400">24h High</p>
                                <p className="font-semibold">70,123.88</p>
                            </div>
                             <div>
                                <p className="text-gray-500 dark:text-gray-400">24h Low</p>
                                <p className="font-semibold">68,890.10</p>
                            </div>
                        </div>
                    </div>

                    {/* Chart & Timeframe */}
                    <div className="bg-white dark:bg-slate-950 rounded-lg p-4 border border-gray-200 dark:border-transparent">
                        <div className="mb-4">
                            <TimeframeControl />
                        </div>
                        <div className="h-80">
                            <ResponsiveContainer width="100%" height="100%">
                               <LineChart data={chartData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                                    <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
                                    <XAxis dataKey="name" stroke={chartColors.axis} fontSize={12} tickLine={false} axisLine={false} />
                                    <YAxis stroke={chartColors.axis} fontSize={12} tickLine={false} axisLine={false} domain={['dataMin - 100', 'dataMax + 100']} tickFormatter={(value) => `$${Number(value).toFixed(0)}`} />
                                    <Tooltip 
                                        contentStyle={{ 
                                            backgroundColor: chartColors.tooltipBg, 
                                            border: `1px solid ${chartColors.tooltipBorder}`,
                                            borderRadius: '0.5rem'
                                        }}
                                        itemStyle={{ color: chartColors.text }}
                                        labelStyle={{ color: chartColors.text, fontWeight: 'bold' }}
                                    />
                                    <Line type="monotone" dataKey="price" stroke="#8b5cf6" strokeWidth={2} dot={false} />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                     {/* Order form on smaller screens */}
                    <div className="lg:hidden">
                        <OrderForm />
                    </div>
                    {/* Orders and History on smaller screens */}
                    <div className="lg:hidden mt-4">
                        <OrdersAndHistory />
                    </div>
                </div>
                {/* Side Content: Order Book and Trades */}
                <div className="lg:col-span-3 space-y-4">
                     <div className="h-96">
                        <OrderBook bids={mockBids} asks={mockAsks} />
                    </div>
                     <div className="h-80">
                         <RecentTrades trades={mockTrades} />
                    </div>
                     {/* Order form on larger screens */}
                    <div className="hidden lg:block">
                        <OrderForm />
                    </div>
                </div>

                 {/* Orders and History for larger screens */}
                 <div className="lg:col-span-12 mt-4 hidden lg:block">
                    <OrdersAndHistory />
                </div>
            </div>
        </div>
    );
};

export default TradingScreen;