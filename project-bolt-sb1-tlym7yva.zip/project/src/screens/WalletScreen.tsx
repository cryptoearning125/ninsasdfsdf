import * as React from 'react';
import { useLocation, useNavigate, Navigate } from 'react-router-dom';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip } from 'recharts';
import { ChevronRight, ArrowLeft, Copy, HelpCircle, Repeat, RefreshCw, ArrowDownLeft, ArrowUpRight, LogOut, CheckCircle, Clock, XCircle, Settings, UploadCloud, Loader, AlertCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.tsx';
import type { User, Transaction, DepositData, WithdrawalData } from '../types.ts';

const mockPrices: { [key: string]: number } = {
  'USDT': 1, 'BTC': 69000.50, 'ETH': 3800.75, 'SOL': 160.25, 'XRP': 0.52, 'USDC': 1.00, 'DOGE': 0.15
};

const ASSET_COLORS: { [key: string]: string } = {
    BTC: '#F7931A', ETH: '#627EEA', USDT: '#26A17B', SOL: '#9945FF', XRP: '#23292F',
    default: '#8884d8'
};
const getAssetColor = (asset: string) => ASSET_COLORS[asset] || ASSET_COLORS.default;

const DepositView = ({ setView }: { setView: (v: string) => void }) => {
    const { deposit, isLoading } = useAuth();
    const [asset, setAsset] = React.useState('USDT');
    const [amount, setAmount] = React.useState('');
    const [senderAddress, setSenderAddress] = React.useState('');
    const [screenshotFile, setScreenshotFile] = React.useState<File | null>(null);
    const [screenshotPreview, setScreenshotPreview] = React.useState<string | null>(null);
    const [error, setError] = React.useState('');
    const [success, setSuccess] = React.useState('');
    const [copied, setCopied] = React.useState(false);
    
    const walletAddress = "0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B"; // Mock Address

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setScreenshotFile(file);
            const reader = new FileReader();
            reader.onloadend = () => setScreenshotPreview(reader.result as string);
            reader.readAsDataURL(file);
        }
    };
    
    const copyToClipboard = () => {
        navigator.clipboard.writeText(walletAddress);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        if (!amount || !senderAddress || !screenshotFile) {
            setError('Please fill all fields and upload a screenshot.');
            return;
        }
        try {
            await deposit({ amount: parseFloat(amount), asset, senderAddress, screenshotFile });
            setSuccess('Deposit request submitted successfully! It will be reviewed shortly.');
            setAmount('');
            setSenderAddress('');
            setScreenshotFile(null);
            setScreenshotPreview(null);
        } catch(err) {
            setError(err instanceof Error ? err.message : 'Submission failed.');
        }
    }

    return (
        <div className="animate-fade-in">
            <header className="sticky top-0 z-10 bg-white/80 dark:bg-black/80 backdrop-blur-lg border-b border-gray-200 dark:border-zinc-800">
                <div className="flex items-center h-16 px-4 max-w-screen-md mx-auto">
                    <button onClick={() => setView('main')} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700"> <ArrowLeft size={24} /> </button>
                    <h1 className="text-lg font-bold text-center flex-1 -ml-10">Deposit</h1>
                </div>
            </header>
            <div className="p-4 max-w-screen-md mx-auto space-y-6 pb-24">
                <div className="bg-white dark:bg-slate-800/50 p-6 rounded-2xl shadow-sm text-center">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Scan QR Code to Deposit {asset}</p>
                    <div className="p-2 bg-white inline-block my-4 rounded-lg">
                        <img src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${walletAddress}`} alt="Deposit QR Code" />
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Wallet Address:</p>
                    <div className="flex items-center justify-center space-x-2 mt-1 font-mono text-sm bg-gray-100 dark:bg-slate-900/50 p-2 rounded-lg">
                        <span className="truncate">{walletAddress}</span>
                        <button onClick={copyToClipboard} className="text-purple-500 hover:text-purple-600">
                            {copied ? <CheckCircle size={18} /> : <Copy size={18} />}
                        </button>
                    </div>
                </div>

                <form onSubmit={handleSubmit} className="bg-white dark:bg-slate-800/50 rounded-2xl p-6 space-y-4 shadow-sm">
                     <h3 className="font-bold text-md text-center">Confirm Your Deposit</h3>
                     {error && <div className="p-3 bg-red-500/10 text-red-500 rounded-lg text-sm flex items-center gap-2"><AlertCircle size={16}/>{error}</div>}
                     {success && <div className="p-3 bg-green-500/10 text-green-500 rounded-lg text-sm flex items-center gap-2"><CheckCircle size={16}/>{success}</div>}
                     
                     <div className="space-y-1">
                        <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Amount ({asset})</label>
                        <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00" required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition"/>
                     </div>
                     <div className="space-y-1">
                        <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Sender Address / TxID</label>
                        <input type="text" value={senderAddress} onChange={e => setSenderAddress(e.target.value)} placeholder="Enter the transaction hash or your sending address" required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition"/>
                     </div>
                      <div className="space-y-1">
                        <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Transaction Screenshot</label>
                         <div className="text-center p-4 border-2 border-dashed border-gray-300 dark:border-slate-700 rounded-lg">
                            <label htmlFor="screenshot" className="cursor-pointer">
                                {screenshotPreview ? (
                                    <img src={screenshotPreview} alt="Screenshot preview" className="w-full h-32 object-contain rounded-md mb-2" />
                                ) : (
                                    <UploadCloud size={32} className="mx-auto text-gray-400 mb-2" />
                                )}
                                <p className="text-sm text-purple-500 dark:text-purple-400 font-semibold">{screenshotFile ? 'Change file' : 'Upload proof'}</p>
                                {screenshotFile && <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 truncate">{screenshotFile.name}</p>}
                            </label>
                            <input id="screenshot" type="file" required className="hidden" accept="image/png, image/jpeg" onChange={handleFileChange} />
                        </div>
                     </div>
                     <button type="submit" disabled={isLoading} className="w-full py-3 mt-2 rounded-lg font-bold text-white bg-purple-600 hover:bg-purple-700 disabled:bg-slate-500 dark:disabled:bg-slate-700 transition-colors flex justify-center items-center">
                       {isLoading ? <Loader className="animate-spin" /> : 'Submit Request'}
                     </button>
                </form>
            </div>
        </div>
    );
};

const WithdrawView = ({ setView }: { setView: (v: string) => void }) => {
    const { user, withdraw, isLoading } = useAuth();
    const [asset, setAsset] = React.useState('USDT');
    const [address, setAddress] = React.useState('');
    const [amount, setAmount] = React.useState('');
    const [fundPassword, setFundPassword] = React.useState('');
    const [error, setError] = React.useState('');
    const [success, setSuccess] = React.useState('');

    const availableBalance = user?.portfolio.balances[asset] || 0;
    const fee = parseFloat(amount) * 0.001 || 0;
    const total = parseFloat(amount) + fee;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        if (total > availableBalance) {
            setError('Insufficient balance.');
            return;
        }
        
        const fundPass = user?.fundPassword || user?.password;
        if (fundPassword !== fundPass) {
            setError(user?.fundPassword ? 'Incorrect fund password.' : 'Incorrect login password.');
            return;
        }

        try {
            await withdraw({ asset, address, amount: parseFloat(amount), fundPassword });
            setSuccess(`Withdrawal request for ${amount} ${asset} submitted successfully.`);
            setAddress('');
            setAmount('');
            setFundPassword('');
        } catch(err) {
            setError(err instanceof Error ? err.message : 'Withdrawal failed.');
        }
    };
    
    return (
        <div className="animate-fade-in">
             <header className="sticky top-0 z-10 bg-white/80 dark:bg-black/80 backdrop-blur-lg border-b border-gray-200 dark:border-zinc-800">
                <div className="flex items-center h-16 px-4 max-w-screen-md mx-auto">
                    <button onClick={() => setView('main')} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700"> <ArrowLeft size={24} /> </button>
                    <h1 className="text-lg font-bold text-center flex-1 -ml-10">Withdraw</h1>
                </div>
            </header>
             <div className="p-4 max-w-screen-md mx-auto space-y-6 pb-24">
                <form onSubmit={handleSubmit} className="bg-white dark:bg-slate-800/50 rounded-2xl p-6 space-y-4 shadow-sm">
                     {error && <div className="p-3 bg-red-500/10 text-red-500 rounded-lg text-sm flex items-center gap-2"><AlertCircle size={16}/>{error}</div>}
                     {success && <div className="p-3 bg-green-500/10 text-green-500 rounded-lg text-sm flex items-center gap-2"><CheckCircle size={16}/>{success}</div>}
                    
                    <div className="space-y-1">
                        <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Asset</label>
                        <select value={asset} onChange={e => setAsset(e.target.value)} className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition appearance-none">
                            {Object.keys(user?.portfolio.balances || {}).map(a => <option key={a} value={a}>{a}</option>)}
                        </select>
                         <p className="text-xs text-right text-gray-500 dark:text-gray-400 pt-1">Available: {availableBalance.toFixed(6)} {asset}</p>
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Withdrawal Address</label>
                        <input type="text" value={address} onChange={e => setAddress(e.target.value)} placeholder={`Enter ${asset} address`} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition"/>
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Amount</label>
                        <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00" required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition"/>
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Fund Password</label>
                        <input type="password" value={fundPassword} onChange={e => setFundPassword(e.target.value)} placeholder={user?.fundPassword ? 'Enter your fund password' : 'Enter your login password'} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition"/>
                    </div>
                    
                    <div className="text-xs text-gray-500 dark:text-gray-400 space-y-1 pt-2 border-t border-gray-100 dark:border-slate-700">
                        <div className="flex justify-between"><span>Fee (0.1%)</span><span>{fee.toFixed(6)} {asset}</span></div>
                        <div className="flex justify-between font-bold text-slate-800 dark:text-white"><span>You will receive</span><span>{Math.max(0, parseFloat(amount) || 0).toFixed(6)} {asset}</span></div>
                    </div>

                    <button type="submit" disabled={isLoading || !amount || !address || !fundPassword || total > availableBalance} className="w-full py-3 mt-2 rounded-lg font-bold text-white bg-purple-600 hover:bg-purple-700 disabled:bg-slate-500 dark:disabled:bg-slate-700 disabled:text-gray-100 dark:disabled:text-gray-400 disabled:cursor-not-allowed transition-colors flex justify-center items-center">
                       {isLoading ? <Loader className="animate-spin" /> : 'Submit Withdrawal'}
                     </button>
                </form>
            </div>
        </div>
    );
};

const HistoryView = ({ setView }: { setView: (v: string) => void }) => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = React.useState('All');
  const [selectedTx, setSelectedTx] = React.useState<Transaction | null>(null);

  const filteredTransactions = React.useMemo(() => {
    if (activeTab === 'All') {
      return user?.transactions || [];
    }
    return user?.transactions.filter(tx => tx.type === activeTab) || [];
  }, [user?.transactions, activeTab]);

  const getStatusColor = (status: Transaction['status']) => {
    switch(status) {
      case 'Completed': return 'text-green-500';
      case 'Pending': return 'text-yellow-500';
      case 'Failed': return 'text-red-500';
    }
  }

  const getTxIcon = (type: Transaction['type']) => {
     switch(type) {
      case 'Deposit': return <ArrowDownLeft size={20} className="text-green-500"/>;
      case 'Withdrawal': return <ArrowUpRight size={20} className="text-red-500"/>;
      case 'Transfer': return <Repeat size={20} className="text-blue-500"/>;
      case 'Exchange': return <RefreshCw size={20} className="text-purple-500"/>;
      default: return <HelpCircle size={20}/>;
     }
  }

  const DetailModal = ({ tx, onClose }: { tx: Transaction, onClose: () => void }) => (
    <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
        <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-md shadow-2xl animate-slide-up" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center p-4 border-b border-gray-200 dark:border-zinc-800">
                 <h2 className="text-xl font-bold">Transaction Details</h2>
                 <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-slate-700">
                    <XCircle size={20}/>
                 </button>
            </div>
            <div className="p-6 space-y-3 text-sm">
                <div className="flex justify-between"><span className="text-gray-500 dark:text-gray-400">Transaction ID</span><span className="font-mono text-xs">{tx.id}</span></div>
                <div className="flex justify-between"><span className="text-gray-500 dark:text-gray-400">Type</span><span className="font-semibold">{tx.type}</span></div>
                <div className="flex justify-between"><span className="text-gray-500 dark:text-gray-400">Status</span><span className={`font-semibold ${getStatusColor(tx.status)}`}>{tx.status}</span></div>
                <div className="flex justify-between"><span className="text-gray-500 dark:text-gray-400">Date</span><span>{new Date(tx.date).toLocaleString()}</span></div>
                <div className="flex justify-between"><span className="text-gray-500 dark:text-gray-400">Asset</span><span>{tx.asset}</span></div>
                <div className="flex justify-between"><span className="text-gray-500 dark:text-gray-400">Amount</span><span className={`font-bold ${tx.type === 'Deposit' ? 'text-green-500' : 'text-red-500'}`}>{tx.amount.toLocaleString()} {tx.asset}</span></div>
                {tx.type === 'Exchange' &&
                 <div className="flex justify-between"><span className="text-gray-500 dark:text-gray-400">Received</span><span className="font-bold">{tx.toAmount?.toLocaleString()} {tx.toAsset}</span></div>
                }
                {tx.type === 'Transfer' &&
                 <div className="flex justify-between"><span className="text-gray-500 dark:text-gray-400">From/To</span><span>{tx.fromAccount} &rarr; {tx.toAccount}</span></div>
                }
                {tx.senderAddress && <div className="flex justify-between"><span className="text-gray-500 dark:text-gray-400">Sender</span><span className="font-mono text-xs truncate">{tx.senderAddress}</span></div>}
                {tx.withdrawalAddress && <div className="flex justify-between"><span className="text-gray-500 dark:text-gray-400">Recipient</span><span className="font-mono text-xs truncate">{tx.withdrawalAddress}</span></div>}
                {tx.screenshotURL && 
                  <div className="pt-2">
                    <p className="text-gray-500 dark:text-gray-400 mb-2">Proof Screenshot</p>
                    <img src={tx.screenshotURL} alt="Transaction screenshot" className="rounded-lg w-full max-h-48 object-contain border border-gray-200 dark:border-slate-700"/>
                  </div>
                }
            </div>
        </div>
    </div>
  );

  return (
    <div className="animate-fade-in">
        <header className="sticky top-0 z-10 bg-white/80 dark:bg-black/80 backdrop-blur-lg border-b border-gray-200 dark:border-zinc-800">
            <div className="flex items-center h-16 px-4">
                <button onClick={() => setView('main')} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700">
                    <ArrowLeft size={24} />
                </button>
                <h1 className="text-lg font-bold text-center flex-1 -ml-10">Transaction History</h1>
            </div>
             <div className="px-4 whitespace-nowrap overflow-x-auto no-scrollbar">
                {['All', 'Deposit', 'Withdrawal', 'Transfer', 'Exchange'].map(tab => (
                    <button key={tab} onClick={() => setActiveTab(tab)} className={`py-2 px-3 text-sm font-semibold transition-colors ${activeTab === tab ? 'text-purple-500 dark:text-purple-400 border-b-2 border-purple-500' : 'text-gray-500 dark:text-gray-400'}`}>
                        {tab}
                    </button>
                ))}
            </div>
        </header>
        <div className="pb-24">
            {filteredTransactions.length > 0 ? (
                <div className="divide-y divide-gray-100 dark:divide-slate-800">
                  {filteredTransactions.map(tx => (
                    <div key={tx.id} onClick={() => setSelectedTx(tx)} className="flex items-center p-4 space-x-4 hover:bg-gray-50 dark:hover:bg-slate-800/50 cursor-pointer">
                        <div className="w-10 h-10 flex items-center justify-center rounded-full bg-gray-100 dark:bg-slate-800">
                            {getTxIcon(tx.type)}
                        </div>
                        <div className="flex-1">
                            <p className="font-bold">{tx.type}</p>
                            <p className="text-xs text-gray-400">{new Date(tx.date).toLocaleString()}</p>
                        </div>
                        <div className="text-right">
                           <p className={`font-bold text-lg ${tx.type === 'Deposit' ? 'text-green-500' : tx.type === 'Withdrawal' ? 'text-red-500' : ''}`}>
                             {tx.type === 'Deposit' ? '+' : tx.type === 'Withdrawal' ? '-' : ''}
                             {tx.amount.toLocaleString('en-US', {minimumFractionDigits: 2})} {tx.asset}
                           </p>
                           <p className={`text-xs font-semibold ${getStatusColor(tx.status)}`}>{tx.status}</p>
                        </div>
                    </div>
                  ))}
                </div>
            ) : (
                <p className="text-center text-gray-500 p-12">No transactions for this category.</p>
            )}
        </div>
        {selectedTx && <DetailModal tx={selectedTx} onClose={() => setSelectedTx(null)}/>}
    </div>
  );
};

const WalletView = ({ user, setView }: { user: User, setView: (view: string) => void }) => {
    const navigate = useNavigate();
    const totalBalance = Object.entries(user.portfolio.balances).reduce((acc, [symbol, amount]) => {
        return acc + amount * (mockPrices[symbol] || 0);
    }, 0);

    const portfolioData = Object.entries(user.portfolio.balances)
        .map(([name, value]) => ({ name, value: value * (mockPrices[name] || 0) }))
        .filter(item => item.value > 0);

    return (
      <div className="animate-fade-in">
        {/* Header */}
        <header className="p-4 bg-white dark:bg-slate-900/95 sticky top-0 z-20 shadow-sm">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold">Wallet</h1>
            <div className="flex items-center space-x-2">
                 <button onClick={() => setView('history')} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800 text-gray-500 dark:text-gray-400">
                    <Clock size={22}/>
                </button>
                 <button onClick={() => navigate('/settings')} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800 text-gray-500 dark:text-gray-400">
                    <Settings size={22}/>
                </button>
            </div>
          </div>
        </header>

        {/* Balance Overview */}
        <div className="p-4 space-y-4">
             <div className="bg-white dark:bg-slate-900 p-6 rounded-xl shadow-lg text-center">
                <p className="text-sm text-gray-500 dark:text-gray-400">Total Assets (USDT)</p>
                <p className="text-4xl font-extrabold my-2">${totalBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                {user.portfolio.pendingBalance > 0 && 
                  <p className="text-xs text-yellow-500">Pending: ${user.portfolio.pendingBalance.toFixed(2)}</p>
                }
             </div>
        
            {/* Action Buttons */}
            <div className="grid grid-cols-4 gap-2 text-center">
                {[
                    { label: 'Deposit', icon: ArrowDownLeft, action: () => setView('deposit') },
                    { label: 'Withdraw', icon: ArrowUpRight, action: () => setView('withdraw') },
                    { label: 'Transfer', icon: Repeat, action: () => navigate('/transfer') },
                    { label: 'Exchange', icon: RefreshCw, action: () => navigate('/exchange') },
                ].map(item => (
                     <button key={item.label} onClick={item.action} className="flex flex-col items-center p-2 space-y-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800">
                        <div className="w-12 h-12 flex items-center justify-center rounded-full bg-purple-100 dark:bg-purple-900/50 text-purple-500 dark:text-purple-400">
                            <item.icon size={24} />
                        </div>
                        <span className="text-xs font-medium">{item.label}</span>
                     </button>
                ))}
            </div>

            {/* Asset Allocation */}
            {portfolioData.length > 0 &&
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl shadow-lg">
                 <h3 className="font-bold text-lg mb-4">Asset Allocation</h3>
                 <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie data={portfolioData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={70} fill="#8884d8" paddingAngle={5}>
                                {portfolioData.map((entry, index) => <Cell key={`cell-${index}`} fill={getAssetColor(entry.name)} />)}
                            </Pie>
                             <RechartsTooltip
                                contentStyle={{ backgroundColor: 'rgba(30, 41, 59, 0.8)', border: '1px solid #334152', borderRadius: '0.5rem', color: '#fff' }}
                                formatter={(value: number, name) => [`$${value.toFixed(2)}`, name]}
                            />
                        </PieChart>
                    </ResponsiveContainer>
                 </div>
            </div>}
        </div>

        {/* Asset List */}
        <div className="px-4 py-2">
            <h3 className="font-bold text-lg mb-2 px-2">My Assets</h3>
            <div className="bg-white dark:bg-slate-900 rounded-xl shadow-lg divide-y divide-gray-100 dark:divide-slate-800">
                {portfolioData.length > 0 ? portfolioData.map(asset => (
                    <div key={asset.name} className="flex items-center p-4 space-x-4">
                        <div className="w-10 h-10 flex items-center justify-center rounded-full" style={{backgroundColor: `${getAssetColor(asset.name)}20`}}>
                             <span className="font-bold text-sm" style={{color: getAssetColor(asset.name)}}>{asset.name.slice(0,1)}</span>
                        </div>
                        <div className="flex-1">
                            <p className="font-bold">{asset.name}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">{user.portfolio.balances[asset.name].toFixed(6)}</p>
                        </div>
                        <div className="text-right">
                           <p className="font-bold text-base">${asset.value.toLocaleString('en-US', {minimumFractionDigits: 2})}</p>
                           <p className="text-xs text-gray-500 dark:text-gray-400">
                            {((asset.value / totalBalance) * 100).toFixed(2)}%
                           </p>
                        </div>
                    </div>
                  )) : (
                    <div className="p-8 text-center text-gray-500">
                        <p>No assets yet.</p>
                        <button onClick={() => setView('deposit')} className="mt-4 text-purple-500 font-semibold">Deposit Now</button>
                    </div>
                  )}
            </div>
        </div>
      </div>
    );
};

const WalletScreen = () => {
    const { user, isLoggedIn } = useAuth();
    const { state } = useLocation();
    const navigate = useNavigate();

    // Default to 'main' view, but allow navigation via state
    const [view, setView] = React.useState(state?.view || 'main');

    React.useEffect(() => {
        if(state?.view) {
            setView(state.view);
            // Clear state after reading it to prevent re-triggering
            navigate('.', { replace: true, state: {} });
        }
    }, [state, navigate]);

    if (!isLoggedIn) {
        // This should be handled by ProtectedRoute, but as a fallback
        return <Navigate to="/login" replace />;
    }
    
    if (!user) {
        return <div className="h-screen flex items-center justify-center"><Loader className="animate-spin" /></div>;
    }
    
    switch (view) {
        case 'deposit':
            return <DepositView setView={setView} />;
        case 'withdraw':
            return <WithdrawView setView={setView} />;
        case 'history':
             return <HistoryView setView={setView} />;
        case 'main':
        default:
            return <WalletView user={user} setView={setView} />;
    }
};

export default WalletScreen;