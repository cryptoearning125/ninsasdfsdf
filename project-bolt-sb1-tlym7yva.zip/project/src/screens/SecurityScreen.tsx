import * as React from 'react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle, AlertCircle, Loader, ShieldCheck, KeyRound, Smartphone, XCircle } from 'lucide-react';

const SecurityModal = ({ title, children, onClose }: { title: string, children: React.ReactNode, onClose: () => void }) => (
    <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
        <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-md shadow-2xl animate-slide-up" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center p-4 border-b border-gray-200 dark:border-zinc-800">
                 <h2 className="text-xl font-bold">{title}</h2>
                 <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-slate-700 text-gray-500 dark:text-gray-300">
                    <XCircle size={20}/>
                 </button>
            </div>
            <div className="p-6">
                {children}
            </div>
        </div>
    </div>
);

const ChangePasswordForm = ({ onClose }: { onClose: () => void }) => {
    const { changePassword } = useAuth();
    const [oldPassword, setOldPassword] = React.useState('');
    const [newPassword, setNewPassword] = React.useState('');
    const [confirmPassword, setConfirmPassword] = React.useState('');
    const [loading, setLoading] = React.useState(false);
    const [error, setError] = React.useState('');
    const [success, setSuccess] = React.useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        if (newPassword !== confirmPassword) {
            setError("New passwords do not match.");
            return;
        }
        if (newPassword.length < 8) {
            setError("Password must be at least 8 characters.");
            return;
        }
        setLoading(true);
        try {
            await changePassword(oldPassword, newPassword);
            setSuccess("Password changed successfully!");
            setTimeout(onClose, 1500);
        } catch(err) {
            setError(err instanceof Error ? err.message : 'Failed to change password.');
        } finally {
            setLoading(false);
        }
    };
    
    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            {error && <div className="p-3 bg-red-500/10 text-red-500 rounded-lg text-sm flex items-center gap-2"><AlertCircle size={16}/>{error}</div>}
            {success && <div className="p-3 bg-green-500/10 text-green-500 rounded-lg text-sm flex items-center gap-2"><CheckCircle size={16}/>{success}</div>}
            
            <input type="password" placeholder="Current Password" value={oldPassword} onChange={e => setOldPassword(e.target.value)} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
            <input type="password" placeholder="New Password" value={newPassword} onChange={e => setNewPassword(e.target.value)} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
            <input type="password" placeholder="Confirm New Password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
            
            <button type="submit" disabled={loading} className="w-full py-3 rounded-lg font-bold text-white bg-purple-600 hover:bg-purple-700 disabled:bg-slate-500 flex justify-center items-center">
                {loading ? <Loader className="animate-spin" /> : 'Confirm Change'}
            </button>
        </form>
    );
};

const FundPasswordForm = ({ onClose }: { onClose: () => void }) => {
    const { setFundPassword, user } = useAuth();
    const [currentPassword, setCurrentPassword] = React.useState('');
    const [newFundPassword, setNewFundPassword] = React.useState('');
    const [confirmFundPassword, setConfirmFundPassword] = React.useState('');
    const [loading, setLoading] = React.useState(false);
    const [error, setError] = React.useState('');
    const [success, setSuccess] = React.useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        if (newFundPassword !== confirmFundPassword) {
            setError("Fund passwords do not match.");
            return;
        }
        if (newFundPassword.length < 6) {
            setError("Fund password must be at least 6 characters.");
            return;
        }
        setLoading(true);
        try {
            await setFundPassword(currentPassword, newFundPassword);
            setSuccess("Fund password set successfully!");
            setTimeout(onClose, 1500);
        } catch(err) {
            setError(err instanceof Error ? err.message : 'Failed to set fund password.');
        } finally {
            setLoading(false);
        }
    };
    
    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <p className="text-xs text-gray-500 dark:text-gray-400">For security, please enter your login password to set or change your fund password.</p>
            {error && <div className="p-3 bg-red-500/10 text-red-500 rounded-lg text-sm flex items-center gap-2"><AlertCircle size={16}/>{error}</div>}
            {success && <div className="p-3 bg-green-500/10 text-green-500 rounded-lg text-sm flex items-center gap-2"><CheckCircle size={16}/>{success}</div>}
            
            <input type="password" placeholder="Current Login Password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
            <input type="password" placeholder="New Fund Password" value={newFundPassword} onChange={e => setNewFundPassword(e.target.value)} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
            <input type="password" placeholder="Confirm Fund Password" value={confirmFundPassword} onChange={e => setConfirmFundPassword(e.target.value)} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
            
            <button type="submit" disabled={loading} className="w-full py-3 rounded-lg font-bold text-white bg-purple-600 hover:bg-purple-700 disabled:bg-slate-500 flex justify-center items-center">
                {loading ? <Loader className="animate-spin" /> : 'Set Fund Password'}
            </button>
        </form>
    );
};

const TwoFactorAuthForm = ({ onClose }: { onClose: () => void }) => {
    const { user, toggle2FA } = useAuth();
    const [password, setPassword] = React.useState('');
    const [code, setCode] = React.useState('');
    const [loading, setLoading] = React.useState(false);
    const [error, setError] = React.useState('');
    
    const handleToggle = async (enable: boolean) => {
        setError('');
        if (!password) {
            setError('Please enter your password.');
            return;
        }
        if (enable && !code) {
             setError('Please enter the 6-digit code from your authenticator app.');
            return;
        }

        setLoading(true);
        try {
            await toggle2FA(password, enable);
            onClose();
        } catch(err) {
            setError(err instanceof Error ? err.message : 'Operation failed.');
        } finally {
            setLoading(false);
        }
    }

    return (
        <div className="space-y-4">
             {error && <div className="p-3 bg-red-500/10 text-red-500 rounded-lg text-sm flex items-center gap-2"><AlertCircle size={16}/>{error}</div>}
             
             {!user?.is2FAEnabled && (
                <div className="text-center space-y-4">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Scan this QR code with your authenticator app (e.g., Google Authenticator).</p>
                    <div className="p-2 bg-white inline-block rounded-lg">
                        <img src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=otpauth://totp/CryptoPulse:${user?.email}?secret=JBSWY3DPEHPK3PXP&issuer=CryptoPulse`} alt="2FA QR Code" />
                    </div>
                     <input type="text" placeholder="Enter 6-digit code" value={code} onChange={e => setCode(e.target.value)} maxLength={6} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
                </div>
             )}
            
            <input type="password" placeholder="Enter Your Login Password" value={password} onChange={e => setPassword(e.target.value)} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
            
            <button onClick={() => handleToggle(!user?.is2FAEnabled)} disabled={loading} className={`w-full py-3 rounded-lg font-bold text-white transition flex justify-center items-center ${user?.is2FAEnabled ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'} disabled:bg-slate-500`}>
                {loading ? <Loader className="animate-spin" /> : (user?.is2FAEnabled ? 'Disable 2FA' : 'Enable 2FA')}
            </button>
        </div>
    )
}

const SecurityScreen = () => {
    const navigate = useNavigate();
    const { user } = useAuth();
    const [activeModal, setActiveModal] = React.useState<null | 'password' | 'fund_password' | '2fa'>(null);

    const securityItems = [
        { label: 'Login Password', icon: ShieldCheck, action: () => setActiveModal('password'), status: "Set" },
        { label: 'Fund Password', icon: KeyRound, action: () => setActiveModal('fund_password'), status: user?.fundPassword ? "Set" : "Not Set" },
        { label: 'Two-Factor Authentication (2FA)', icon: Smartphone, action: () => setActiveModal('2fa'), status: user?.is2FAEnabled ? "Enabled" : "Disabled" }
    ];

    return (
        <div className="animate-fade-in bg-gray-50 dark:bg-black min-h-screen text-slate-900 dark:text-white">
            <header className="sticky top-0 z-50 bg-white/80 dark:bg-black/80 backdrop-blur-lg border-b border-gray-200 dark:border-zinc-800">
                <div className="flex items-center justify-between h-16 px-4 max-w-screen-lg mx-auto">
                    <button onClick={() => navigate(-1)} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700">
                        <ArrowLeft size={24} />
                    </button>
                    <h1 className="text-lg font-bold">Security Center</h1>
                    <div className="w-10"></div>
                </div>
            </header>
            
            <main className="p-4 md:p-8 max-w-screen-lg mx-auto space-y-4">
                <div className="bg-white dark:bg-slate-900 rounded-lg shadow-sm divide-y divide-gray-100 dark:divide-slate-800">
                    {securityItems.map(item => (
                        <button key={item.label} onClick={item.action} className="w-full flex items-center justify-between p-4 hover:bg-gray-50 dark:hover:bg-slate-800/50">
                            <div className="flex items-center space-x-4">
                                <item.icon className="text-gray-500 dark:text-gray-400" size={22}/>
                                <span className="font-semibold text-slate-800 dark:text-white">{item.label}</span>
                            </div>
                            <div className={`px-2 py-0.5 text-xs font-semibold rounded-full ${item.status.includes('Set') || item.status === 'Enabled' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{item.status}</div>
                        </button>
                    ))}
                </div>
            </main>
            
            {activeModal === 'password' && (
                <SecurityModal title="Change Login Password" onClose={() => setActiveModal(null)}>
                    <ChangePasswordForm onClose={() => setActiveModal(null)} />
                </SecurityModal>
            )}
             {activeModal === 'fund_password' && (
                <SecurityModal title="Set Fund Password" onClose={() => setActiveModal(null)}>
                    <FundPasswordForm onClose={() => setActiveModal(null)} />
                </SecurityModal>
            )}
             {activeModal === '2fa' && (
                <SecurityModal title="Two-Factor Authentication" onClose={() => setActiveModal(null)}>
                    <TwoFactorAuthForm onClose={() => setActiveModal(null)} />
                </SecurityModal>
            )}
        </div>
    );
};

export default SecurityScreen;