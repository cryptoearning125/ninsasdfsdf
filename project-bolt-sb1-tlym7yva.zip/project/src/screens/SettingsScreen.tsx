import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Bell, Lock, Sun, Moon, CreditCard, Landmark, HelpCircle, Info, UserCheck, Camera } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { useTheme } from '../contexts/ThemeContext.tsx';

const SettingsScreen = () => {
    const { user, logout, updateUserPhoto } = useAuth();
    const { theme, toggleTheme } = useTheme();
    const navigate = useNavigate();
    const fileInputRef = React.useRef<HTMLInputElement>(null);

    if (!user) {
        return null; // or a loader
    }

    const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            try {
                await updateUserPhoto(e.target.files[0]);
            } catch (error) {
                console.error("Failed to update photo", error);
                // Optionally show an error to the user
            }
        }
    };
   
    return (
      <div className="animate-fade-in bg-gray-50 dark:bg-black min-h-screen">
        {/* Header */}
        <header className="sticky top-0 z-50 bg-white/80 dark:bg-black/80 backdrop-blur-lg border-b border-gray-200 dark:border-zinc-800">
            <div className="flex items-center justify-between h-16 px-4 max-w-screen-lg mx-auto">
                <button onClick={() => navigate(-1)} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700">
                    <ArrowLeft size={24} />
                </button>
                <h1 className="text-lg font-bold">Settings</h1>
                <div className="w-10"></div>
            </div>
        </header>

        {/* Main Content */}
        <main className="p-4 max-w-screen-lg mx-auto">
            {/* User Profile Section */}
            <div className="flex items-center space-x-4 mb-6">
                <div className="relative group">
                    <img src={user.photoURL || `https://i.pravatar.cc/150?u=${user.uid}`} alt="User" className="w-16 h-16 rounded-full border-2 border-purple-500 object-cover" />
                    <input type="file" ref={fileInputRef} onChange={handlePhotoChange} className="hidden" accept="image/*" id="photo-upload" />
                    <label htmlFor="photo-upload" className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                        <Camera size={24} className="text-white"/>
                    </label>
                </div>
                <div className="flex-1">
                  <h2 className="font-bold text-xl">{user.name}</h2>
                  <p className="text-sm text-gray-500 dark:text-gray-400">UID: {user.uid}</p>
                </div>
            </div>

            {/* Settings List */}
            <div className="bg-white dark:bg-slate-900 rounded-lg shadow-sm divide-y divide-gray-100 dark:divide-slate-800">
                {[
                    { label: 'Identity Authentication', icon: UserCheck, action: () => navigate('/identity-authentication'), status: user.identityStatus },
                    { label: 'Security Center', icon: Lock, action: () => navigate('/security') },
                    { label: 'Notification Settings', icon: Bell, action: () => {} },
                    { label: 'Payment Settings', icon: CreditCard, action: () => {} },
                    { label: 'Language', icon: Landmark, action: () => {} },
                    { label: 'Theme', icon: theme === 'light' ? Moon : Sun, action: toggleTheme, status: theme },
                    { label: 'Help Center', icon: HelpCircle, action: () => {} },
                    { label: 'About Us', icon: Info, action: () => navigate('/about') },
                ].map(item => (
                    <button key={item.label} onClick={item.action} className="w-full flex items-center justify-between p-4 hover:bg-gray-50 dark:hover:bg-slate-800/50">
                        <div className="flex items-center space-x-4">
                            <item.icon className="text-gray-500 dark:text-gray-400" size={22}/>
                            <span className="font-semibold text-slate-800 dark:text-white">{item.label}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                            {item.status && <span className="text-sm text-gray-500 dark:text-gray-400 capitalize">{item.status}</span>}
                        </div>
                    </button>
                ))}
            </div>

            {/* Logout Button */}
            <div className="mt-6">
                 <button onClick={logout} className="w-full text-center p-3 bg-red-500/10 text-red-500 dark:bg-red-500/20 dark:text-red-400 font-bold rounded-lg hover:bg-red-500/20 dark:hover:bg-red-500/30 transition-colors">
                    Logout
                </button>
            </div>
        </main>
      </div>
    );
};

export default SettingsScreen;