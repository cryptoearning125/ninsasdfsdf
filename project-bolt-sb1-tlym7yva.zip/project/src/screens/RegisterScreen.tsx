import * as React from 'react';
import { useNavigate, NavLink } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext.tsx';
import { Loader, AlertCircle, Eye, EyeOff } from 'lucide-react';

const RegisterScreen = () => {
    const { signup, isLoading } = useAuth();
    const navigate = useNavigate();
    const [formData, setFormData] = React.useState({
        firstName: '',
        lastName: '',
        country: 'US',
        birthDate: '',
        email: '',
        phoneNumber: '',
        password: '',
        referralCode: '',
        termsOfUse: false,
        explicitConsent: false,
        commercialMessage: false,
        recaptcha: false,
    });
    const [showPassword, setShowPassword] = React.useState(false);
    const [error, setError] = React.useState('');

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        if (type === 'checkbox') {
            const { checked } = e.target as HTMLInputElement;
            setFormData(prev => ({ ...prev, [name]: checked }));
        } else {
            setFormData(prev => ({ ...prev, [name]: value }));
        }
    };

    const isFormValid = () => {
        const { firstName, lastName, email, password, birthDate, country, phoneNumber, termsOfUse, explicitConsent, recaptcha } = formData;
        return firstName && lastName && email && password.length >= 8 && birthDate && country && phoneNumber && termsOfUse && explicitConsent && recaptcha;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!isFormValid()) {
            setError("Please fill all required fields and accept the terms.");
            return;
        }
        try {
            await signup({
                firstName: formData.firstName,
                lastName: formData.lastName,
                email: formData.email,
                password: formData.password,
                country: formData.country,
                birthDate: formData.birthDate,
                phone: formData.phoneNumber
            });
            navigate('/');
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        }
    };
    
    return (
        <div className="min-h-screen bg-gray-50 dark:bg-black p-4 flex flex-col justify-center animate-fade-in">
            <div className="max-w-lg mx-auto w-full space-y-4">
                <div className="text-left">
                    <h1 className="text-2xl font-bold">Register to <span className="text-purple-500">CryptoPulse</span></h1>
                </div>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                    {error && <div className="p-3 bg-red-500/10 text-red-500 rounded-lg text-sm flex items-center gap-2"><AlertCircle size={16}/>{error}</div>}
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1">
                            <label className="text-xs font-medium text-gray-500 dark:text-gray-400">First Name</label>
                            <input name="firstName" type="text" onChange={handleChange} placeholder="Enter first name" required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition"/>
                        </div>
                        <div className="space-y-1">
                            <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Last Name</label>
                            <input name="lastName" type="text" onChange={handleChange} placeholder="Enter last name" required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition"/>
                        </div>
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Country</label>
                        <select name="country" value={formData.country} onChange={handleChange} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition appearance-none">
                            <option value="US">United States</option>
                            <option value="CA">Canada</option>
                            <option value="GB">United Kingdom</option>
                            <option value="AU">Australia</option>
                            <option value="DE">Germany</option>
                            <option value="FR">France</option>
                            <option value="JP">Japan</option>
                            <option value="CN">China</option>
                        </select>
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Birth Date</label>
                        <input name="birthDate" type="date" onChange={handleChange} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition"/>
                    </div>
                    
                    <div className="space-y-1">
                        <label className="text-xs font-medium text-gray-500 dark:text-gray-400">E-Mail</label>
                        <input name="email" type="email" placeholder="Enter e-mail address" value={formData.email} onChange={handleChange} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition"/>
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Phone Number</label>
                        <input name="phoneNumber" type="tel" placeholder="Phone number" value={formData.phoneNumber} onChange={handleChange} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition"/>
                    </div>

                    <div className="space-y-1 relative">
                        <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Password</label>
                        <input name="password" type={showPassword ? "text" : "password"} placeholder="Set password" value={formData.password} onChange={handleChange} required className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition"/>
                         <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-8 text-gray-500 dark:text-gray-400">
                            {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                         </button>
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Referral Code (Optional)</label>
                        <input name="referralCode" type="text" placeholder="Enter referral code" onChange={handleChange} className="w-full bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition"/>
                    </div>
                    
                    <div className="space-y-3 pt-2">
                        <label className="flex items-start space-x-3 cursor-pointer">
                            <input type="checkbox" name="termsOfUse" checked={formData.termsOfUse} onChange={handleChange} className="mt-0.5 h-4 w-4 text-purple-600 bg-gray-100 dark:bg-slate-900 border-gray-300 dark:border-slate-600 rounded focus:ring-purple-500" />
                            <span className="text-xs text-gray-600 dark:text-gray-400">I have read and agree to the <a href="#" className="text-purple-500 hover:underline">Usage Agreement</a> and the <a href="#" className="text-purple-500 hover:underline">Personal Data Disclosure</a>.</span>
                        </label>
                         <label className="flex items-start space-x-3 cursor-pointer">
                            <input type="checkbox" name="explicitConsent" checked={formData.explicitConsent} onChange={handleChange} className="mt-0.5 h-4 w-4 text-purple-600 bg-gray-100 dark:bg-slate-900 border-gray-300 dark:border-slate-600 rounded focus:ring-purple-500" />
                            <span className="text-xs text-gray-600 dark:text-gray-400">I have read the <a href="#" className="text-purple-500 hover:underline">Privacy Policy</a> and consent to the processing and transfer of my personal data.</span>
                        </label>
                         <label className="flex items-start space-x-3 cursor-pointer">
                            <input type="checkbox" name="commercialMessage" checked={formData.commercialMessage} onChange={handleChange} className="mt-0.5 h-4 w-4 text-purple-600 bg-gray-100 dark:bg-slate-900 border-gray-300 dark:border-slate-600 rounded focus:ring-purple-500" />
                            <span className="text-xs text-gray-600 dark:text-gray-400">I consent to receiving commercial electronic messages.</span>
                        </label>
                    </div>

                    <div className="space-y-2 pt-2">
                         <label className="flex items-center space-x-3 cursor-pointer">
                            <input type="checkbox" name="recaptcha" checked={formData.recaptcha} onChange={handleChange} className="h-4 w-4 text-purple-600 bg-gray-100 dark:bg-slate-900 border-gray-300 dark:border-slate-600 rounded focus:ring-purple-500" />
                            <span className="text-sm text-gray-600 dark:text-gray-400">I'm not a robot</span>
                        </label>
                    </div>
                    
                    <button type="submit" disabled={isLoading || !isFormValid()} className="w-full py-3 rounded-lg font-bold text-white bg-purple-600 hover:bg-purple-700 disabled:bg-slate-500 disabled:cursor-not-allowed transition flex justify-center items-center">
                        {isLoading ? <Loader className="animate-spin"/> : 'Register'}
                    </button>
                    
                    <p className="text-center text-sm text-gray-500 dark:text-gray-400">
                        Already have an account?{' '}
                        <NavLink to="/login" className="font-semibold text-purple-500 hover:underline">Login here</NavLink>
                    </p>
                </form>
            </div>
        </div>
    );
};

export default RegisterScreen;