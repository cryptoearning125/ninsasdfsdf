import * as React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext.tsx';
import { apiGetIcoById } from '../server/api.ts';
import type { Ico } from '../types.ts';
import { ArrowLeft, Loader } from 'lucide-react';

const SubscriptionDetailsScreen = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const { user } = useAuth();
    const [ico, setIco] = React.useState<Ico | null>(null);
    const [loading, setLoading] = React.useState(true);
    const [error, setError] = React.useState<string | null>(null);
    const [amount, setAmount] = React.useState('');

    React.useEffect(() => {
        if (id) {
            setLoading(true);
            apiGetIcoById(id)
                .then(setIco)
                .catch(err => setError(err.message))
                .finally(() => setLoading(false));
        } else {
            setError("No ICO ID provided.");
            setLoading(false);
        }
    }, [id]);

    const handleSubscribe = () => {
        if (!amount || Number(amount) <= 0) {
            alert("Please enter a valid amount.");
            return;
        }
        alert(`Subscribed ${amount} USDT to ${ico?.name}! (Mock action)`);
    };

    if (loading) {
        return <div className="flex justify-center items-center h-screen bg-black text-white"><Loader className="animate-spin" size={48} /></div>;
    }
    
    if (error || !ico) {
        return (
            <div className="flex flex-col justify-center items-center h-screen bg-black text-red-500">
                <p>{error || 'ICO not found.'}</p>
                 <button onClick={() => navigate(-1)} className="mt-4 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                    Go Back
                </button>
            </div>
        );
    }

    const availableBalance = user?.portfolio.balance || 0;

    return (
        <div className="dark text-white bg-black min-h-screen">
            <header className="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-lg border-b border-zinc-800">
                <div className="flex items-center justify-between h-16 px-4">
                     <button onClick={() => navigate(-1)} className="p-2 rounded-full hover:bg-slate-700">
                        <ArrowLeft size={24} />
                    </button>
                    <h1 className="text-lg font-bold">{ico.name.replace(' ICO subscription', '')}</h1>
                    <div className="w-16 text-right">
                         <button onClick={() => navigate('/wallet', { state: { view: 'history' } })} className="text-sm text-purple-400 font-semibold">
                            History
                        </button>
                    </div>
                </div>
            </header>
            
            <main className="p-4 space-y-5 pb-20">
                <div className="bg-slate-800/50 p-5 rounded-lg">
                    <div className="flex flex-col text-lg py-4">
                        <span className="mr-2 text-gray-400 text-sm">Balance</span>
                        <span className="font-semibold">{availableBalance.toFixed(8)} USDT</span>
                    </div>
                    <div className="border-t border-b border-zinc-700 py-4">
                        <p className="text-gray-400 text-sm mb-1">Issue price</p>
                        <p className="text-2xl font-bold text-purple-400">1{ico.id.toUpperCase()} = {ico.issuePrice} {ico.issueCurrency}</p>
                    </div>
                     <div className="border-b border-zinc-700 py-4 space-y-2">
                        <div className="flex justify-between text-sm">
                            <span className="text-white">Number of issues</span>
                            <span className="text-purple-400">{ico.total.toLocaleString()} {ico.id.toUpperCase()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                            <span className="text-white">Remaining quantity</span>
                            <span className="text-purple-400">{Math.round(ico.total - ico.subscribed).toLocaleString()} {ico.id.toUpperCase()}</span>
                        </div>
                    </div>
                    <div className="grid grid-cols-2 text-sm text-white pt-4 gap-y-4">
                        <div>
                            <p className="mb-1 text-gray-400">Subscription currency</p>
                            <p>{ico.subscriptionCurrencies[0]}</p>
                        </div>
                         <div>
                            <p className="mb-1 text-gray-400">Estimated online time</p>
                            <p>{ico.onlineTime}</p>
                        </div>
                        <div>
                            <p className="mb-1 text-gray-400">Start time</p>
                            <p>{ico.startTime}</p>
                        </div>
                        <div>
                            <p className="mb-1 text-gray-400">End time</p>
                            <p>{ico.endTime}</p>
                        </div>
                    </div>
                </div>

                <div className="flex h-12 my-6">
                    <div className="w-28 mr-3 text-white border-b-2 border-solid border-purple-500 h-full flex justify-center items-center">
                        <span className="text-lg">{ico.issueCurrency}</span>
                    </div>
                    <div className="flex-1 border-b-2 border-solid border-purple-500 h-full flex items-center">
                        <input
                            type="number"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            placeholder="Please enter the amount"
                            className="h-full w-full bg-transparent text-xl px-4 text-white placeholder-gray-500 focus:outline-none"
                        />
                        <button onClick={() => setAmount(String(availableBalance))} className="text-lg px-4 text-purple-400 font-semibold">All</button>
                    </div>
                </div>

                <button onClick={handleSubscribe} className="w-full text-center rounded-lg p-3 text-white text-lg font-semibold bg-purple-600 hover:bg-purple-700 transition-colors">
                    Immediate subscription
                </button>

                <div className="bg-slate-800/50 p-5 rounded-lg">
                    <h3 className="text-xl text-white font-bold mb-3">Introduce</h3>
                    <p className="text-gray-300 text-sm leading-relaxed">{ico.introduction}</p>
                </div>
            </main>
        </div>
    );
};

export default SubscriptionDetailsScreen;