import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import type { CryptoCoin } from '../types.ts';
import { Loader } from 'lucide-react';

const MarketsScreen = () => {
    const [coins, setCoins] = React.useState<CryptoCoin[]>([]);
    const [loading, setLoading] = React.useState<boolean>(true);
    const [error, setError] = React.useState<string | null>(null);
    const [activeTab, setActiveTab] = React.useState('USDT');
    const navigate = useNavigate();

    const fetchCoinData = React.useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            const response = await fetch(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false`);
            if (!response.ok) {
                throw new Error('Failed to fetch data from CoinGecko API. Please try again later.');
            }
            const data: CryptoCoin[] = await response.json();
            setCoins(data);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setLoading(false);
        }
    }, []);
    
    React.useEffect(() => {
        fetchCoinData();
    }, [fetchCoinData]);

    const CurrencyTab = ({ currency }: { currency: string}) => {
        const isActive = activeTab === currency;
        return (
            <div className="inline-flex flex-col items-center mr-8 text-center cursor-pointer">
                <span
                    onClick={() => setActiveTab(currency)}
                    className={`pb-2 text-base font-semibold transition-colors ${isActive ? 'text-purple-500 dark:text-purple-400' : 'text-gray-500 dark:text-gray-400'}`}
                >
                    {currency}
                </span>
                {isActive && <div className="w-10 h-1 bg-purple-500 rounded-full"></div>}
            </div>
        );
    }
    
    const CoinRow = ({ coin }: { coin: CryptoCoin }) => {
        const isPositive = coin.price_change_percentage_24h !== null && coin.price_change_percentage_24h >= 0;
        const priceChangeColor = isPositive ? 'bg-green-500' : 'bg-red-500';

        return (
            <div 
                className="flex items-center text-sm text-gray-400 px-5 py-4 border-b border-gray-100 dark:border-zinc-800 cursor-pointer hover:bg-gray-100 dark:hover:bg-zinc-800/50"
                onClick={() => navigate(`/trading/${coin.symbol.toUpperCase()}-USDT`)}
            >
                <div className="flex items-center" style={{ flex: 1.5 }}>
                    <img src={coin.image} alt={coin.name} className="w-8 h-8 mr-4 rounded-full" />
                    <div>
                        <span className="text-base font-bold text-slate-900 dark:text-white">{coin.symbol.toUpperCase()}</span>
                        <span className="text-xs text-gray-500 dark:text-gray-400">/USDT</span>
                    </div>
                </div>
                <div className="flex-1 text-base text-slate-900 dark:text-white font-semibold">
                    {coin.current_price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 6 })}
                </div>
                <div className="flex-1 flex justify-end">
                    <div className={`w-24 h-9 flex justify-center items-center rounded-md text-center text-white font-bold text-sm ${priceChangeColor}`}>
                        {isPositive ? '+' : ''}{coin.price_change_percentage_24h?.toFixed(2)}%
                    </div>
                </div>
            </div>
        );
    }

    const TableHeader = () => (
        <div className="flex items-center text-xs text-gray-500 dark:text-gray-400 px-5 py-2">
            <span style={{ flex: 1.5 }}>Name</span>
            <span className="flex-1">Latest price</span>
            <span className="flex-1 text-right">Rise and fall</span>
        </div>
    );
    
    return (
        <div className="animate-fade-in bg-white dark:bg-black min-h-screen">
            <header className="px-4 pt-3 border-b border-gray-100 dark:border-zinc-800">
                <div className="whitespace-nowrap overflow-x-auto no-scrollbar">
                     {['USDT', 'BTC', 'ETH', 'Favorites'].map(tab => (
                        <CurrencyTab key={tab} currency={tab} />
                    ))}
                </div>
            </header>
            
            <main className="pb-20">
                <TableHeader />
                {loading ? (
                    <div className="flex flex-col justify-center items-center space-y-2 py-24">
                        <Loader className="animate-spin h-8 w-8 text-purple-500" />
                        <span>Loading Markets...</span>
                    </div>
                ) : error ? (
                    <div className="text-center py-24 text-red-500 px-4">
                        <p className="font-semibold text-slate-900 dark:text-white">Error loading market data.</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">{error}</p>
                        <button onClick={fetchCoinData} className="mt-4 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                            Try Again
                        </button>
                    </div>
                ) : (
                    <div>
                        {coins.map(coin => <CoinRow key={coin.id} coin={coin} />)}
                    </div>
                )}
            </main>
        </div>
    );
};

export default MarketsScreen;