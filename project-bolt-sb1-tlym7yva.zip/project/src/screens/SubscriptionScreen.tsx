import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Loader } from 'lucide-react';
import type { Ico } from '../types.ts';
import { apiGetIcos } from '../server/api.ts';

const StatusChip = ({ status }: { status: Ico['status'] }) => {
    let colorClasses = '';
    switch (status) {
        case 'In progress':
            colorClasses = 'border-green-500 text-green-500 dark:border-green-400 dark:text-green-400';
            break;
        case 'Listed':
            colorClasses = 'border-blue-500 text-blue-500 dark:border-blue-400 dark:text-blue-400';
            break;
        case 'Ended':
            colorClasses = 'border-gray-500 text-gray-500 dark:border-gray-400 dark:text-gray-400';
            break;
    }
    return (
        <div className={`rounded-lg py-1 px-3 border-2 border-solid text-sm font-semibold ${colorClasses}`}>
            {status}
        </div>
    );
};

const IcoCard = ({ ico }: { ico: Ico }) => {
    const navigate = useNavigate();
    const progress = 100 - ico.remainingPercentage;

    return (
        <div onClick={() => navigate(`/subscription/${ico.id}`)} className="bg-white dark:bg-slate-800/50 rounded-xl p-5 mb-5 shadow-sm cursor-pointer hover:ring-2 hover:ring-purple-500 transition-all">
            <div className="flex justify-between items-center mb-3">
                <h2 className="text-xl font-bold">{ico.name}</h2>
                <span className="text-sm rounded-lg py-1 px-3 text-white bg-purple-500">{ico.tag}</span>
            </div>
            <div className="flex justify-between items-center mb-5">
                <StatusChip status={ico.status} />
            </div>
            <div className="flex justify-between items-center mb-3 text-sm">
                <div className="text-gray-500 dark:text-gray-400">
                    <span className="font-bold text-slate-900 dark:text-white">{ico.subscribed.toLocaleString()}</span> / {ico.total.toLocaleString()} {ico.id.toUpperCase()}
                </div>
                <div className="text-gray-500 dark:text-gray-400">
                    Remaining: <span className="font-bold text-slate-900 dark:text-white">{ico.remainingPercentage.toFixed(2)}%</span>
                </div>
            </div>
            <div className="w-full h-4 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden">
                <div className="h-full bg-yellow-500 rounded-full flex items-center justify-end" style={{ width: `${progress}%` }}>
                     <span className="px-2 text-xs text-white font-bold">{`${progress.toFixed(2)}%`}</span>
                </div>
            </div>
        </div>
    )
};

const SubscriptionScreen = () => {
    const navigate = useNavigate();
    const [icos, setIcos] = React.useState<Ico[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [error, setError] = React.useState<string | null>(null);

    React.useEffect(() => {
        const fetchIcos = async () => {
            setLoading(true);
            setError(null);
            try {
                const data = await apiGetIcos();
                setIcos(data);
            } catch(e) {
                 setError(e instanceof Error ? e.message : 'An unknown error occurred');
            } finally {
                setLoading(false);
            }
        };
        fetchIcos();
    }, []);

    return (
        <div className="animate-fade-in">
            <header className="sticky top-0 z-50 bg-white/80 dark:bg-black/80 backdrop-blur-lg border-b border-gray-200 dark:border-zinc-800">
                <div className="flex items-center justify-between h-16 px-4">
                     <button onClick={() => navigate(-1)} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700">
                        <ArrowLeft size={24} />
                    </button>
                    <h1 className="text-lg font-bold">ICO subscription</h1>
                    <div className="w-16 text-right">
                         <button onClick={() => {}} className="text-sm text-purple-500 dark:text-purple-400 font-semibold">
                            History
                        </button>
                    </div>
                </div>
            </header>

            <main className="p-4">
                {loading ? (
                     <div className="flex flex-col justify-center items-center space-y-2 py-24">
                        <Loader className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500" />
                        <span>Loading ICOs...</span>
                    </div>
                ): error ? (
                     <div className="text-center py-24 text-red-500 px-4">
                        <p className="font-semibold text-slate-900 dark:text-white">Error loading data.</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">{error}</p>
                    </div>
                ) : (
                    icos.map(ico => <IcoCard key={ico.id} ico={ico} />)
                )}
            </main>
        </div>
    );
};

export default SubscriptionScreen;