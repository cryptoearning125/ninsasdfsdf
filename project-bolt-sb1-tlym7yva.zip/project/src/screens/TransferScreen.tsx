import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext.tsx';
import { ArrowLeft, Repeat, Loader, CheckCircle, AlertCircle } from 'lucide-react';

// Define account types for display purposes
const accountTypes = {
  spot: "Spot Account",
  seconds: "Seconds Account"
};

const TransferScreen = () => {
  const navigate = useNavigate();
  const { user, transferFunds, isLoading } = useAuth();
  
  const [fromAccount, setFromAccount] = React.useState<'spot' | 'seconds'>('spot');
  const [toAccount, setToAccount] = React.useState<'spot' | 'seconds'>('seconds');
  const [amount, setAmount] = React.useState('');
  const [asset] = React.useState('USDT'); // Only USDT supported for now
  const [error, setError] = React.useState('');
  const [success, setSuccess] = React.useState('');

  const spotBalance = user?.portfolio.balance || 0;
  const secondsBalance = user?.secondContractPortfolio.balance || 0;
  
  const fromBalance = fromAccount === 'spot' ? spotBalance : secondsBalance;

  const handleSwap = () => {
    setFromAccount(toAccount);
    setToAccount(fromAccount);
  };
  
  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    const transferAmount = parseFloat(amount);
    if (isNaN(transferAmount) || transferAmount <= 0) {
      setError("Please enter a valid amount.");
      return;
    }
    
    if (transferAmount > fromBalance) {
      setError("Insufficient balance.");
      return;
    }

    try {
      await transferFunds(fromAccount, toAccount, transferAmount, asset);
      setSuccess(`Successfully transferred ${transferAmount} ${asset}.`);
      setAmount('');
    } catch(err) {
      setError(err instanceof Error ? err.message : 'Transfer failed.');
    } finally {
        setTimeout(() => {
            setSuccess('');
            setError('');
        }, 4000);
    }
  };
  
  const transferHistory = user?.transactions.filter(tx => tx.type === 'Transfer').slice(0, 10) || [];
  
  return (
    <div className="animate-fade-in bg-gray-50 dark:bg-black min-h-screen text-slate-900 dark:text-white">
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-black/80 backdrop-blur-lg border-b border-gray-200 dark:border-zinc-800">
          <div className="flex items-center justify-between h-16 px-4 max-w-screen-md mx-auto">
              <button onClick={() => navigate(-1)} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700">
                  <ArrowLeft size={24} />
              </button>
              <h1 className="text-lg font-bold">Transfer</h1>
              <div className="w-10"></div>
          </div>
      </header>

      <main className="p-4 max-w-screen-md mx-auto space-y-6 pb-24">
        {/* Account Selection Card */}
        <div className="bg-white dark:bg-slate-800/50 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center">
            {/* From Account */}
            <div className="flex-1 space-y-1">
              <span className="text-xs text-gray-500 dark:text-gray-400">From</span>
              <p className="font-bold text-lg">{accountTypes[fromAccount]}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">Balance: {fromBalance.toFixed(2)} {asset}</p>
            </div>
            {/* Swap Button */}
            <button onClick={handleSwap} className="p-3 bg-gray-100 dark:bg-slate-700 rounded-full mx-4 hover:bg-purple-100 dark:hover:bg-purple-900/50 text-purple-500 dark:text-purple-400 transition-colors">
              <Repeat size={20} />
            </button>
            {/* To Account */}
            <div className="flex-1 space-y-1 text-right">
              <span className="text-xs text-gray-500 dark:text-gray-400">To</span>
              <p className="font-bold text-lg">{accountTypes[toAccount]}</p>
            </div>
          </div>
        </div>

        {/* Amount Input */}
        <form onSubmit={handleTransfer} className="bg-white dark:bg-slate-800/50 rounded-2xl p-4 space-y-4 shadow-sm">
          <h3 className="font-bold text-md">Transfer Amount</h3>
          <div className="flex items-end space-x-2">
            <span className="text-2xl font-bold">{asset}</span>
            <input 
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount"
              className="w-full text-2xl font-bold bg-transparent border-b-2 border-gray-200 dark:border-slate-700 focus:border-purple-500 focus:outline-none transition pb-1"
            />
            <button type="button" onClick={() => setAmount(String(fromBalance))} className="text-purple-500 dark:text-purple-400 font-semibold text-sm">ALL</button>
          </div>
          
           {error && <div className="p-3 bg-red-500/10 text-red-500 rounded-lg text-sm flex items-center gap-2"><AlertCircle size={16}/>{error}</div>}
           {success && <div className="p-3 bg-green-500/10 text-green-500 rounded-lg text-sm flex items-center gap-2"><CheckCircle size={16}/>{success}</div>}

          <button type="submit" disabled={isLoading || !amount || parseFloat(amount) <= 0 || parseFloat(amount) > fromBalance} className="w-full py-3 mt-2 rounded-lg font-bold text-white bg-purple-600 hover:bg-purple-700 disabled:bg-slate-500 dark:disabled:bg-slate-700 disabled:text-gray-100 dark:disabled:text-gray-400 disabled:cursor-not-allowed transition-colors flex justify-center items-center">
            {isLoading ? <Loader className="animate-spin" /> : 'Confirm Transfer'}
          </button>
        </form>
        
        {/* History */}
        <div className="space-y-3">
          <h3 className="text-xl font-bold px-2">Transfer History</h3>
           <div className="bg-white dark:bg-slate-800/50 rounded-2xl p-2 shadow-sm">
             {transferHistory.length > 0 ? (
                <div className="divide-y divide-gray-100 dark:divide-slate-700">
                  {transferHistory.map(tx => (
                    <div key={tx.id} className="grid grid-cols-3 gap-2 py-3 px-2 text-sm">
                      <div>
                        <p className="font-semibold text-slate-900 dark:text-white">{accountTypes[tx.fromAccount as keyof typeof accountTypes]}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">to {accountTypes[tx.toAccount as keyof typeof accountTypes]}</p>
                      </div>
                      <div className="text-center">
                        <p className="font-semibold text-slate-900 dark:text-white">{tx.amount.toFixed(2)} {tx.asset}</p>
                      </div>
                       <div className="text-right">
                        <p className="text-xs text-gray-500 dark:text-gray-400">{new Date(tx.date).toLocaleDateString()}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{new Date(tx.date).toLocaleTimeString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
             ) : (
                <p className="text-center text-gray-500 dark:text-gray-400 py-8">No transfer history yet.</p>
             )}
           </div>
        </div>

      </main>
    </div>
  );
};

export default TransferScreen;