import * as React from 'react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { useTheme } from '../contexts/ThemeContext.tsx';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import type { SecondContractTrade, NewSecondContractData } from '../types.ts';
import { Loader, ArrowUp, ArrowDown, Check, Wallet, Info, Trophy, AlertTriangle, ChevronDown } from 'lucide-react';

// Mock data for chart
const chartData = Array.from({ length: 50 }, (_, i) => ({
  name: `T-${50-i}`,
  price: 68000 + Math.sin(i / 5) * 500 + Math.random() * 200,
}));

const contractOptions = [
    { duration: 30, profitRate: 0.75 },
    { duration: 60, profitRate: 0.80 },
    { duration: 120, profitRate: 0.85 },
    { duration: 180, profitRate: 0.90 },
    { duration: 300, profitRate: 0.95 },
];

const Header = () => {
    const [price, setPrice] = React.useState(chartData[chartData.length - 1].price);
    const [isUp, setIsUp] = React.useState(true);

    React.useEffect(() => {
        const interval = setInterval(() => {
            setPrice(prev => {
                const change = (Math.random() - 0.5) * 50;
                const newPrice = prev + change;
                setIsUp(change >= 0);
                return newPrice;
            });
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="flex items-center justify-between p-4 bg-white dark:bg-slate-950 rounded-lg shadow-md border border-gray-200 dark:border-transparent">
            <div className={`flex flex-col text-3xl font-bold ${isUp ? 'text-green-500' : 'text-red-500'}`}>
                <span>{price.toFixed(2)}</span>
            </div>
            <div className="text-right text-sm">
                <div className="flex justify-between items-center gap-4"><span className="text-gray-500 dark:text-gray-400">24h High</span><span className="font-semibold">69,876.54</span></div>
                <div className="flex justify-between items-center gap-4"><span className="text-gray-500 dark:text-gray-400">24h Low</span><span className="font-semibold">67,123.45</span></div>
                <div className="flex justify-between items-center gap-4"><span className="text-gray-500 dark:text-gray-400">24h Vol</span><span className="font-semibold">4.5B USDT</span></div>
            </div>
        </div>
    );
};

const Chart = () => {
    const { theme } = useTheme();
    const chartColors = {
        grid: theme === 'dark' ? '#374151' : '#e5e7eb',
        axis: theme === 'dark' ? '#9ca3af' : '#6b7280',
        tooltipBg: theme === 'dark' ? '#1f2937' : '#ffffff',
        tooltipBorder: theme === 'dark' ? '#374151' : '#e5e7eb',
        text: theme === 'dark' ? '#f8fafc' : '#1e293b'
    };

    return (
        <div className="bg-white dark:bg-slate-950 rounded-lg p-2 h-72 border border-gray-200 dark:border-transparent">
            <ResponsiveContainer width="100%" height="100%">
               <LineChart data={chartData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
                    <XAxis dataKey="name" stroke={chartColors.axis} fontSize={12} tickLine={false} axisLine={false} hide/>
                    <YAxis stroke={chartColors.axis} fontSize={12} tickLine={false} axisLine={false} domain={['dataMin - 100', 'dataMax + 100']} tickFormatter={(value) => `$${Number(value).toFixed(0)}`} />
                    <Tooltip 
                        contentStyle={{ backgroundColor: chartColors.tooltipBg, border: `1px solid ${chartColors.tooltipBorder}`, borderRadius: '0.5rem' }}
                        itemStyle={{ color: chartColors.text }} labelStyle={{ color: chartColors.text, fontWeight: 'bold' }}
                    />
                    <Line type="monotone" dataKey="price" stroke="#8b5cf6" strokeWidth={2} dot={false} />
                </LineChart>
            </ResponsiveContainer>
        </div>
    );
};

const Countdown = ({ to, onEnd }: { to: string, onEnd: () => void }) => {
    const [remaining, setRemaining] = React.useState('');
    
    React.useEffect(() => {
        const interval = setInterval(() => {
            const now = new Date();
            const target = new Date(to);
            const diff = target.getTime() - now.getTime();
            if (diff <= 0) {
                setRemaining('00:00');
                clearInterval(interval);
                onEnd();
            } else {
                const minutes = Math.floor((diff / 1000) / 60);
                const seconds = Math.floor((diff / 1000) % 60);
                setRemaining(`${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`);
            }
        }, 1000);
        return () => clearInterval(interval);
    }, [to, onEnd]);

    return <span className="font-mono">{remaining}</span>;
}

const SecondContractScreen = () => {
    const { user, placeSecondContractTrade, resolveSecondContracts } = useAuth();
    const [selectedOption, setSelectedOption] = React.useState(contractOptions[0]);
    const [amount, setAmount] = React.useState('10');
    const [isLoading, setIsLoading] = React.useState(false);
    const [error, setError] = React.useState('');
    const [activeTab, setActiveTab] = React.useState<'active' | 'history'>('active');

    React.useEffect(() => {
        const interval = setInterval(() => {
            if(user?.activeSecondContracts && user.activeSecondContracts.length > 0) {
                 resolveSecondContracts();
            }
        }, 2000);
        return () => clearInterval(interval);
    }, [user?.activeSecondContracts, resolveSecondContracts]);
    
    const handleTrade = async (type: 'buy' | 'sell') => {
        setError('');
        if (!amount || Number(amount) <= 0) {
            setError('Please enter a valid amount.');
            return;
        }
        if (Number(amount) > (user?.secondContractPortfolio.balance || 0)) {
            setError('Insufficient balance.');
            return;
        }

        setIsLoading(true);
        const tradeData: NewSecondContractData = {
            pair: 'BTC-USDT',
            type,
            duration: selectedOption.duration,
            profitRate: selectedOption.profitRate,
            amount: Number(amount),
        };

        try {
            await placeSecondContractTrade(tradeData);
        } catch(e) {
            setError(e instanceof Error ? e.message : 'An error occurred.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const TradeRow = ({ trade }: { trade: SecondContractTrade }) => (
        <div className="grid grid-cols-4 gap-2 text-xs py-3 px-4 border-b border-gray-100 dark:border-zinc-800 last:border-0">
            <div className={`font-bold ${trade.type === 'buy' ? 'text-green-500' : 'text-red-500'}`}>
                {trade.type === 'buy' ? 'Up' : 'Down'} / {trade.duration}s
            </div>
            <div className="text-gray-500 dark:text-gray-300">{trade.amount} USDT</div>
             <div className="text-gray-500 dark:text-gray-300 font-semibold">{trade.entryPrice.toFixed(2)}</div>
            <div className="text-right">
                {trade.status === 'active' ? (
                     <Countdown to={trade.closesAt} onEnd={resolveSecondContracts}/>
                ) : (
                    <span className={`font-bold ${trade.status === 'won' ? 'text-green-500' : 'text-red-500'}`}>
                        {trade.status === 'won' ? `+${(trade.amount * trade.profitRate).toFixed(2)}` : `-${trade.amount.toFixed(2)}`}
                    </span>
                )}
            </div>
        </div>
    );

    return (
        <div className="p-2 lg:p-4 max-w-screen-2xl mx-auto text-slate-900 dark:text-white space-y-4">
            <Header />
            <Chart />

            <div className="bg-white dark:bg-slate-950 rounded-lg p-4 border border-gray-200 dark:border-transparent">
                <p className="text-sm font-semibold mb-3">Time / Profit Rate</p>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                    {contractOptions.map(opt => (
                        <button key={opt.duration} onClick={() => setSelectedOption(opt)} className={`p-2 rounded-lg text-center transition-all duration-200 ${selectedOption.duration === opt.duration ? 'bg-purple-600 text-white ring-2 ring-purple-400' : 'bg-gray-100 dark:bg-slate-800 hover:bg-gray-200 dark:hover:bg-slate-700'}`}>
                            <p className="font-bold">{opt.duration}s</p>
                            <p className="text-xs">+{opt.profitRate * 100}%</p>
                        </button>
                    ))}
                </div>
            </div>
            
            <div className="bg-white dark:bg-slate-950 rounded-lg p-4 border border-gray-200 dark:border-transparent space-y-4">
                <div>
                     <div className="flex justify-between items-center text-sm mb-2">
                        <label htmlFor="amount-input" className="font-semibold">Amount</label>
                         <span className="text-gray-500 dark:text-gray-400 flex items-center gap-1">
                           <Wallet size={14}/> {user?.secondContractPortfolio?.balance.toFixed(2) || '0.00'} USDT
                        </span>
                    </div>
                    <div className="relative">
                        <input id="amount-input" type="number" value={amount} onChange={e => setAmount(e.target.value)}
                         className="w-full bg-gray-100 dark:bg-slate-900 border border-gray-300 dark:border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">USDT</span>
                    </div>
                    {error && <p className="text-red-500 text-xs mt-2">{error}</p>}
                </div>
                <div className="grid grid-cols-2 gap-4">
                     <button onClick={() => handleTrade('buy')} disabled={isLoading} className="py-4 rounded-lg bg-green-500 hover:bg-green-600 text-white font-bold text-lg flex justify-center items-center gap-2 transition disabled:bg-slate-500">
                        {isLoading ? <Loader className="animate-spin" /> : <><ArrowUp /> Up</>}
                    </button>
                    <button onClick={() => handleTrade('sell')} disabled={isLoading} className="py-4 rounded-lg bg-red-500 hover:bg-red-600 text-white font-bold text-lg flex justify-center items-center gap-2 transition disabled:bg-slate-500">
                       {isLoading ? <Loader className="animate-spin" /> : <><ArrowDown /> Down</>}
                    </button>
                </div>
            </div>
            
            <div className="bg-white dark:bg-slate-950 rounded-lg border border-gray-200 dark:border-transparent">
                 <div className="flex border-b border-gray-100 dark:border-zinc-800">
                    <button onClick={() => setActiveTab('active')} className={`px-4 py-3 font-semibold ${activeTab === 'active' ? 'text-purple-500 border-b-2 border-purple-500' : 'text-gray-500'}`}>Active ({user?.activeSecondContracts?.length || 0})</button>
                    <button onClick={() => setActiveTab('history')} className={`px-4 py-3 font-semibold ${activeTab === 'history' ? 'text-purple-500 border-b-2 border-purple-500' : 'text-gray-500'}`}>History</button>
                </div>
                <div className="grid grid-cols-4 gap-2 text-xs text-gray-400 dark:text-gray-500 font-bold p-4">
                    <span>Type/Time</span>
                    <span>Amount</span>
                    <span>Entry Price</span>
                    <span className="text-right">Outcome</span>
                </div>
                 <div className="max-h-64 overflow-y-auto">
                    {activeTab === 'active' && (
                        user?.activeSecondContracts?.length ? user.activeSecondContracts.map(t => <TradeRow key={t.id} trade={t} />) 
                        : <p className="text-center text-gray-500 p-8">No active trades.</p>
                    )}
                     {activeTab === 'history' && (
                        user?.secondContractHistory?.length ? user.secondContractHistory.map(t => <TradeRow key={t.id} trade={t} />) 
                        : <p className="text-center text-gray-500 p-8">No trade history.</p>
                    )}
                </div>
            </div>

        </div>
    );
};

export default SecondContractScreen;