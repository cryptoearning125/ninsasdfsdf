import type { User, Transaction, UserPortfolio, Ico, UserOrder, NewOrderData, UpdateOrderData, SecondContractTrade, NewSecondContractData, WithdrawalData } from '../types.ts';

// --- MOCK DATABASE ---
const DB_STORAGE_KEY = 'cryptoPulseDB';

// Default state if nothing is in localStorage
const initialDb: { users: Record<string, User>; icos: Record<string, Ico>; } = {
  users: {
    'demo@cryptopulse.com': {
      name: 'Demo User',
      email: 'demo@cryptopulse.com',
      uid: 'UID-DEMO',
      password: 'demo123',
      identityStatus: 'verified',
      is2FAEnabled: false,
      fundPassword: '',
      portfolio: {
        balance: 10000,
        pendingBalance: 0,
        pl: 0,
        plPercentage: 0,
        balances: { 'USDT': 10000, 'BTC': 0.1, 'ETH': 2.5 }
      },
      secondContractPortfolio: {
        balance: 1000,
      },
      transactions: [],
      openOrders: [],
      orderHistory: [],
      activeSecondContracts: [],
      secondContractHistory: [],
    },
  },
  icos: {
    'solk': {
      id: 'solk',
      name: 'Solana Killer ICO subscription',
      status: 'In progress',
      tag: 'Hot',
      subscribed: 15000000,
      total: 50000000,
      remainingPercentage: 70,
      issuePrice: 0.10,
      issueCurrency: 'USDT',
      subscriptionCurrencies: ['USDT'],
      startTime: '2025-07-01',
      endTime: '2025-07-31',
      onlineTime: '2025-08-15',
      introduction: 'SOLK is a revolutionary new blockchain designed to outperform Solana in every metric. With its innovative consensus mechanism and parallel transaction processing, SOLK aims to be the go-to platform for decentralized applications.'
    },
    'aic': {
      id: 'aic',
      name: 'AI Chain ICO subscription',
      status: 'In progress',
      tag: 'AI',
      subscribed: 80000000,
      total: 100000000,
      remainingPercentage: 20,
      issuePrice: 0.50,
      issueCurrency: 'USDT',
      subscriptionCurrencies: ['USDT'],
      startTime: '2025-06-15',
      endTime: '2025-07-15',
      onlineTime: '2025-08-01',
      introduction: 'AI Chain integrates artificial intelligence at the core layer of the blockchain, enabling smart contracts to learn and adapt. This will revolutionize DeFi, gaming, and data management.'
    },
    'qtr': {
      id: 'qtr',
      name: 'Quantum Resist ICO subscription',
      status: 'Ended',
      tag: 'Security',
      subscribed: 25000000,
      total: 25000000,
      remainingPercentage: 0,
      issuePrice: 0.25,
      issueCurrency: 'USDT',
      subscriptionCurrencies: ['USDT', 'BTC'],
      startTime: '2025-05-01',
      endTime: '2025-05-31',
      onlineTime: '2025-06-15',
      introduction: 'QTR is the first blockchain built to be fully resistant to attacks from quantum computers. Secure your assets for the future with Quantum Resist technology.'
    },
    'dfp': {
      id: 'dfp',
      name: 'DeFi Pulse ICO subscription',
      status: 'Listed',
      tag: 'DeFi',
      subscribed: 75000000,
      total: 75000000,
      remainingPercentage: 0,
      issuePrice: 1.20,
      issueCurrency: 'USDT',
      subscriptionCurrencies: ['USDT', 'ETH'],
      startTime: '2025-04-01',
      endTime: '2025-04-30',
      onlineTime: '2025-05-15',
      introduction: 'DeFi Pulse is an all-in-one ecosystem for decentralized finance, offering lending, borrowing, staking, and a decentralized exchange with unparalleled capital efficiency.'
    }
  }
};

let db: { users: Record<string, User>; icos: Record<string, Ico>; };

const mockPrices: { [key: string]: number } = {
  'USDT': 1,
  'BTC': 69000.50,
  'ETH': 3800.75,
  'SOL': 160.25,
  'XRP': 0.52,
  'USDC': 1.00,
  'DOGE': 0.15
};

const saveDb = () => {
    try {
        localStorage.setItem(DB_STORAGE_KEY, JSON.stringify(db));
    } catch (e) {
        console.error("Could not save mock DB to localStorage", e);
    }
};

const loadDb = () => {
    let needsSave = false;
    const defaultUserEmail = 'demo@cryptopulse.com';
    try {
        const savedDbString = localStorage.getItem(DB_STORAGE_KEY);
        if (savedDbString) {
            db = JSON.parse(savedDbString);

            if (!db.users) db.users = {};
            if (!db.icos) db.icos = {};

            // Ensure the default user exists and is fully populated
            const defaultUser = db.users[defaultUserEmail];
            if (!defaultUser) {
                db.users[defaultUserEmail] = JSON.parse(JSON.stringify(initialDb.users[defaultUserEmail]));
                needsSave = true;
            } else {
                 // Patch other missing fields for forward compatibility
                 if (!defaultUser.identityStatus) { defaultUser.identityStatus = 'not-verified'; needsSave = true; }
                 if (defaultUser.is2FAEnabled === undefined) { defaultUser.is2FAEnabled = false; needsSave = true; }
                 if (defaultUser.fundPassword === undefined) { defaultUser.fundPassword = ''; needsSave = true; }
                 if (!defaultUser.portfolio) { defaultUser.portfolio = { balance: 0, pendingBalance: 0, pl: 0, plPercentage: 0, balances: {'USDT': 0} }; needsSave = true; }
                 if (!defaultUser.portfolio.balances) { defaultUser.portfolio.balances = {'USDT': 0}; needsSave = true; }
                 if (!defaultUser.secondContractPortfolio) { defaultUser.secondContractPortfolio = { balance: 0 }; needsSave = true; }
                 if (!defaultUser.transactions) { defaultUser.transactions = []; needsSave = true; }
                 if (!defaultUser.openOrders) { defaultUser.openOrders = []; needsSave = true; }
                 if (!defaultUser.orderHistory) { defaultUser.orderHistory = []; needsSave = true; }
                 if (!defaultUser.activeSecondContracts) { defaultUser.activeSecondContracts = []; needsSave = true; }
                 if (!defaultUser.secondContractHistory) { defaultUser.secondContractHistory = []; needsSave = true; }
            }
            
            if (!db.icos || Object.keys(db.icos).length === 0) {
                 db.icos = JSON.parse(JSON.stringify(initialDb.icos));
                 needsSave = true;
            }

        } else {
            db = JSON.parse(JSON.stringify(initialDb));
            needsSave = true;
        }

        if (needsSave) {
            saveDb();
        }

    } catch (e) {
        console.error("Failed to load or parse mock DB, resetting to initial state.", e);
        db = JSON.parse(JSON.stringify(initialDb));
        saveDb();
    }
};

loadDb();


// --- API SIMULATION ---
const apiCall = <T>(data: T, delay = 500): Promise<T> => 
  new Promise(resolve => setTimeout(() => resolve(data), delay));

const apiError = (message: string, delay = 500): Promise<any> =>
  new Promise((_, reject) => setTimeout(() => reject(new Error(message)), delay));

interface SignupData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  country: string;
  birthDate: string;
  phone: string;
}

// --- EXPORTED API FUNCTIONS ---

export const apiSignup = (data: SignupData): Promise<{user: User, token: string}> => {
  loadDb();
  if (db.users[data.email]) {
    return apiError("An account with this email already exists.");
  }
  
  const fullName = `${data.firstName} ${data.lastName}`;
  const uid = 'UID-' + Math.random().toString(36).substring(2, 11).toUpperCase();

  const newUser: User = { 
      name: fullName, 
      email: data.email, 
      uid, 
      password: data.password,
      country: data.country,
      birthDate: data.birthDate,
      phone: data.phone,
      identityStatus: 'not-verified',
      is2FAEnabled: false,
      fundPassword: '',
      portfolio: { balance: 0, pendingBalance: 0, pl: 0, plPercentage: 0, balances: {'USDT': 0} },
      secondContractPortfolio: { balance: 0 },
      transactions: [],
      openOrders: [],
      orderHistory: [],
      activeSecondContracts: [],
      secondContractHistory: [],
  };

  db.users[data.email] = newUser;
  saveDb();
  const { password: _, ...userToReturn } = newUser;
  
  return apiCall({ user: userToReturn, token: `TOKEN_${uid}`});
};

export const apiLogin = (email: string, password: string): Promise<{user: User, token: string}> => {
  loadDb();
  const user = db.users[email];
  if (user && user.password === password) {
    const { password: _, ...userToReturn } = user;
    return apiCall({ user: userToReturn, token: `TOKEN_${user.uid}`});
  }
  return apiError("Invalid credentials.");
};

export const apiGetUserByToken = (token: string): Promise<User> => {
    loadDb();
    const uid = token.replace('TOKEN_', '');
    const user = Object.values(db.users).find(u => u.uid === uid);
    if (user) {
        const { password: _, ...userToReturn } = user;
        return apiCall(userToReturn);
    }
    return apiError("Invalid session token.");
}

export const apiDeposit = (
  token: string, 
  data: { amount: number; asset: string; senderAddress: string; screenshotURL: string }
): Promise<User> => {
    loadDb();
    const uid = token.replace('TOKEN_', '');
    const user = Object.values(db.users).find(u => u.uid === uid);

    if (!user || data.amount <= 0) {
        return apiError("Invalid request.");
    }

    const newTransaction: Transaction = {
      id: `tx-${Math.random().toString(36).substring(2, 9)}`,
      type: 'Deposit',
      asset: data.asset,
      amount: data.amount,
      status: 'Pending',
      date: new Date().toISOString(),
      senderAddress: data.senderAddress,
      screenshotURL: data.screenshotURL,
    };

    user.portfolio.pendingBalance += data.amount;
    user.transactions.unshift(newTransaction);
    saveDb();

    const { password: _, ...userToReturn } = user;
    return apiCall(userToReturn);
}

export const apiApproveDeposit = (token: string, transactionId: string): Promise<User> => {
    loadDb();
    const uid = token.replace('TOKEN_', '');
    const user = Object.values(db.users).find(u => u.uid === uid);

    if (!user) return apiError("Invalid user.");

    const transaction = user.transactions.find(tx => tx.id === transactionId);
    
    if (!transaction || transaction.status !== 'Pending' || transaction.type !== 'Deposit') {
        return apiError("Transaction not found or not eligible for approval.");
    }

    user.portfolio.pendingBalance -= transaction.amount;
    transaction.status = 'Completed';
    
    const asset = transaction.asset;
    const amount = transaction.amount;

    // Update the main balance (assuming all deposits add to the main USDT equivalent balance for simplicity)
    const price = mockPrices[asset] || 1; // Fallback to 1 if price is unknown
    user.portfolio.balance += amount * price;

    // Update the specific asset balance
    if (!user.portfolio.balances) user.portfolio.balances = {};
    user.portfolio.balances[asset] = (user.portfolio.balances[asset] || 0) + amount;
    
    saveDb();
    
    const { password: _, ...userToReturn } = user;
    return apiCall(userToReturn);
}

export const apiWithdraw = (token: string, data: WithdrawalData): Promise<User> => {
    loadDb();
    const uid = token.replace('TOKEN_', '');
    const user = Object.values(db.users).find(u => u.uid === uid);

    if (!user) return apiError("Invalid user.");
    if (data.amount <= 0) return apiError("Withdrawal amount must be positive.");
    
    // Check fund password if it's set
    if (user.fundPassword && user.fundPassword !== data.fundPassword) {
        return apiError("Incorrect fund password.");
    }
    // If fund password is not set, we require login password for security
    if (!user.fundPassword && user.password !== data.fundPassword) {
        return apiError("Incorrect login password. Please set a fund password for withdrawals.");
    }

    const assetBalance = user.portfolio.balances[data.asset] || 0;
    const fee = data.amount * 0.001; // 0.1% fee
    const totalDeduction = data.amount + fee;

    if (assetBalance < totalDeduction) {
        return apiError(`Insufficient ${data.asset} balance.`);
    }

    const newTransaction: Transaction = {
      id: `tx-withdraw-${Math.random().toString(36).substring(2, 9)}`,
      type: 'Withdrawal',
      asset: data.asset,
      amount: data.amount,
      status: 'Pending',
      date: new Date().toISOString(),
      withdrawalAddress: data.address,
    };

    user.transactions.unshift(newTransaction);
    
    // Lock the funds by deducting from balance
    user.portfolio.balances[data.asset] -= totalDeduction;
    if(data.asset === 'USDT') {
      user.portfolio.balance -= totalDeduction;
    }
    
    saveDb();

    const { password: _, ...userToReturn } = user;
    return apiCall(userToReturn);
};

export const apiApproveWithdrawal = (token: string, transactionId: string): Promise<User> => {
    loadDb();
    const uid = token.replace('TOKEN_', '');
    const user = Object.values(db.users).find(u => u.uid === uid);

    if (!user) return apiError("Invalid user.");

    const transaction = user.transactions.find(tx => tx.id === transactionId);
    
    if (!transaction || transaction.status !== 'Pending' || transaction.type !== 'Withdrawal') {
        return apiError("Withdrawal request not found or not eligible for approval.");
    }

    transaction.status = 'Completed';
    // Funds are already deducted, so we just finalize the state.
    
    saveDb();
    
    const { password: _, ...userToReturn } = user;
    return apiCall(userToReturn);
}

export const apiGetIcos = (): Promise<Ico[]> => {
    loadDb();
    const icos = Object.values(db.icos || {});
    return apiCall(icos);
};

export const apiGetIcoById = (id: string): Promise<Ico> => {
    loadDb();
    const ico = db.icos?.[id];
    if (ico) {
        return apiCall(ico);
    }
    return apiError("ICO not found.");
};

export const apiPlaceOrder = (token: string, orderData: NewOrderData): Promise<{ user: User, newOrder: UserOrder }> => {
  loadDb();
  const uid = token.replace('TOKEN_', '');
  const user = Object.values(db.users).find(u => u.uid === uid);
  if (!user) return apiError("Invalid user.");
  
  const newOrder: UserOrder = {
    ...orderData,
    id: `order-${Math.random().toString(36).substring(2, 9)}`,
    status: 'open',
    createdAt: new Date().toISOString(),
    filled: 0,
  };
  
  if (!user.openOrders) user.openOrders = [];
  user.openOrders.unshift(newOrder);
  saveDb();
  
  const { password: _, ...userToReturn } = user;
  return apiCall({ user: userToReturn, newOrder }, 800);
}

export const apiCancelOrder = (token: string, orderId: string): Promise<{ user: User, cancelledOrder: UserOrder }> => {
  loadDb();
  const uid = token.replace('TOKEN_', '');
  const user = Object.values(db.users).find(u => u.uid === uid);
  if (!user) return apiError("Invalid user.");
  
  const orderIndex = user.openOrders.findIndex(o => o.id === orderId);
  if (orderIndex === -1) return apiError("Order not found.");
  
  const [cancelledOrder] = user.openOrders.splice(orderIndex, 1);
  cancelledOrder.status = 'cancelled';
  
  if (!user.orderHistory) user.orderHistory = [];
  user.orderHistory.unshift(cancelledOrder);
  
  saveDb();
  
  const { password: _, ...userToReturn } = user;
  return apiCall({ user: userToReturn, cancelledOrder }, 300);
}

export const apiModifyOrder = (token: string, orderId: string, updateData: UpdateOrderData): Promise<{ user: User, updatedOrder: UserOrder }> => {
  loadDb();
  const uid = token.replace('TOKEN_', '');
  const user = Object.values(db.users).find(u => u.uid === uid);
  if (!user) return apiError("Invalid user.");

  const orderIndex = user.openOrders.findIndex(o => o.id === orderId);
  if (orderIndex === -1) return apiError("Order not found.");

  const originalOrder = user.openOrders[orderIndex];
  const updatedOrder = { ...originalOrder, ...updateData };
  user.openOrders[orderIndex] = updatedOrder;

  saveDb();

  const { password: _, ...userToReturn } = user;
  return apiCall({ user: userToReturn, updatedOrder }, 300);
};

export const apiPlaceSecondContractTrade = (token: string, tradeData: NewSecondContractData): Promise<{ user: User, newTrade: SecondContractTrade }> => {
    loadDb();
    const uid = token.replace('TOKEN_', '');
    const user = Object.values(db.users).find(u => u.uid === uid);
    if (!user) return apiError("Invalid user.");
    
    if (user.secondContractPortfolio.balance < tradeData.amount) {
        return apiError("Insufficient balance for this trade.");
    }
    
    const now = new Date();
    const closesAt = new Date(now.getTime() + tradeData.duration * 1000);

    // Mock an entry price based on some recent price
    const entryPrice = 68000 + Math.sin(Date.now() / 50000) * 500 + Math.random() * 200;

    const newTrade: SecondContractTrade = {
        ...tradeData,
        id: `sctrade-${Math.random().toString(36).substring(2, 9)}`,
        entryPrice: entryPrice,
        status: 'active',
        createdAt: now.toISOString(),
        closesAt: closesAt.toISOString(),
    };

    if (!user.activeSecondContracts) user.activeSecondContracts = [];
    user.activeSecondContracts.unshift(newTrade);
    user.secondContractPortfolio.balance -= tradeData.amount;
    
    saveDb();
    
    const { password: _, ...userToReturn } = user;
    return apiCall({ user: userToReturn, newTrade }, 500);
};

export const apiResolveSecondContracts = (token: string): Promise<User> => {
    loadDb();
    const uid = token.replace('TOKEN_', '');
    const user = Object.values(db.users).find(u => u.uid === uid);
    if (!user) return apiError("Invalid user.");
    
    const now = new Date();
    const stillActiveContracts: SecondContractTrade[] = [];
    let hasChanged = false;

    if (!user.activeSecondContracts) user.activeSecondContracts = [];
    if (!user.secondContractHistory) user.secondContractHistory = [];

    user.activeSecondContracts.forEach(trade => {
        if (new Date(trade.closesAt) <= now) {
            hasChanged = true;
            // This contract has expired, resolve it.
            const closePrice = trade.entryPrice + (Math.random() - 0.5) * 200; // Mock close price
            trade.closePrice = closePrice;

            const isWin = (trade.type === 'buy' && closePrice > trade.entryPrice) || (trade.type === 'sell' && closePrice < trade.entryPrice);

            if (isWin) {
                trade.status = 'won';
                const profit = trade.amount * trade.profitRate;
                const totalReturn = trade.amount + profit;
                user.secondContractPortfolio.balance += totalReturn;
            } else {
                trade.status = 'lost';
                // Amount was already deducted, so no change on loss.
            }
            user.secondContractHistory.unshift(trade);
        } else {
            // This contract is still active
            stillActiveContracts.push(trade);
        }
    });

    if (hasChanged) {
      user.activeSecondContracts = stillActiveContracts;
      saveDb();
    }
    
    const { password: _, ...userToReturn } = user;
    return apiCall(userToReturn, 100);
};

export const apiTransferFunds = (token: string, fromAccount: 'spot' | 'seconds', toAccount: 'spot' | 'seconds', amount: number, asset: string): Promise<User> => {
  loadDb();
  const uid = token.replace('TOKEN_', '');
  const user = Object.values(db.users).find(u => u.uid === uid);
  if (!user) return apiError("Invalid user.");
  if (fromAccount === toAccount) return apiError("Cannot transfer to the same account.");
  if (amount <= 0) return apiError("Transfer amount must be positive.");
  
  // This mock API only supports USDT transfers between spot and seconds for now.
  if (asset !== 'USDT') return apiError("Only USDT transfers are supported at this time.");

  // Deduct from source
  if (fromAccount === 'spot') {
    if (user.portfolio.balance < amount) return apiError("Insufficient funds in Spot Account.");
    user.portfolio.balance -= amount;
    if (user.portfolio.balances) {
      user.portfolio.balances[asset] = (user.portfolio.balances[asset] || 0) - amount;
    }
  } else if (fromAccount === 'seconds') {
    if (user.secondContractPortfolio.balance < amount) return apiError("Insufficient funds in Seconds Account.");
    user.secondContractPortfolio.balance -= amount;
  } else {
    return apiError("Invalid source account.");
  }

  // Add to destination
  if (toAccount === 'spot') {
    user.portfolio.balance += amount;
    if (!user.portfolio.balances) user.portfolio.balances = {};
    user.portfolio.balances[asset] = (user.portfolio.balances[asset] || 0) + amount;
  } else if (toAccount === 'seconds') {
    user.secondContractPortfolio.balance += amount;
  } else {
    // Revert deduction if destination is invalid
    if (fromAccount === 'spot') {
        user.portfolio.balance += amount;
        if (user.portfolio.balances) {
           user.portfolio.balances[asset] = (user.portfolio.balances[asset] || 0) + amount;
        }
    }
    else if (fromAccount === 'seconds') user.secondContractPortfolio.balance += amount;
    return apiError("Invalid destination account.");
  }
  
  const newTransaction: Transaction = {
    id: `tx-transfer-${Math.random().toString(36).substring(2, 9)}`,
    type: 'Transfer',
    asset: asset,
    amount: amount,
    status: 'Completed',
    date: new Date().toISOString(),
    fromAccount,
    toAccount,
  };

  if(!user.transactions) user.transactions = [];
  user.transactions.unshift(newTransaction);
  saveDb();
  
  const { password: _, ...userToReturn } = user;
  return apiCall(userToReturn, 500);
};

export const apiExchangeAssets = (token: string, fromAsset: string, toAsset: string, fromAmount: number): Promise<User> => {
    loadDb();
    const uid = token.replace('TOKEN_', '');
    const user = Object.values(db.users).find(u => u.uid === uid);
    if (!user) return apiError("Invalid user.");
    if (fromAsset === toAsset) return apiError("Cannot exchange the same asset.");
    if (fromAmount <= 0) return apiError("Exchange amount must be positive.");
    if (!mockPrices[fromAsset] || !mockPrices[toAsset]) return apiError("Exchange for one of the assets is not supported.");
    
    const fromBalance = user.portfolio.balances?.[fromAsset] || 0;
    if (fromBalance < fromAmount) return apiError("Insufficient funds.");

    const exchangeRate = mockPrices[fromAsset] / mockPrices[toAsset];
    const toAmount = fromAmount * exchangeRate;

    // Update balances
    if (!user.portfolio.balances) {
        user.portfolio.balances = {};
    }
    user.portfolio.balances[fromAsset] -= fromAmount;
    user.portfolio.balances[toAsset] = (user.portfolio.balances[toAsset] || 0) + toAmount;

    // Update main USDT balance if involved
    if (fromAsset === 'USDT') {
        user.portfolio.balance -= fromAmount;
    }
    if (toAsset === 'USDT') {
        user.portfolio.balance += toAmount;
    }

    // Add transaction record
    const newTransaction: Transaction = {
        id: `tx-exchange-${Math.random().toString(36).substring(2, 9)}`,
        type: 'Exchange',
        asset: fromAsset,
        amount: fromAmount,
        status: 'Completed',
        date: new Date().toISOString(),
        toAsset: toAsset,
        toAmount: toAmount,
    };
    if (!user.transactions) user.transactions = [];
    user.transactions.unshift(newTransaction);
    saveDb();

    const { password: _, ...userToReturn } = user;
    return apiCall(userToReturn, 500);
};


export const apiSubmitIdentityDocs = (
  token: string, 
  docs: { idFrontUrl: string; idBackUrl: string; selfieUrl: string }
): Promise<User> => {
    loadDb();
    const uid = token.replace('TOKEN_', '');
    const user = Object.values(db.users).find(u => u.uid === uid);

    if (!user) {
        return apiError("Invalid request.");
    }
    
    user.identityStatus = 'pending';
    user.identityDocuments = docs;
    saveDb();

    const { password: _, ...userToReturn } = user;
    return apiCall(userToReturn, 1000);
};

export const apiApproveIdentity = (token: string): Promise<User> => {
    loadDb();
    const uid = token.replace('TOKEN_', '');
    const user = Object.values(db.users).find(u => u.uid === uid);
    if (!user) return apiError("Invalid user.");

    if (user.identityStatus !== 'pending') {
        return apiError("No pending verification to approve.");
    }

    user.identityStatus = 'verified';
    saveDb();
    
    const { password: _, ...userToReturn } = user;
    return apiCall(userToReturn);
};

export const apiChangePassword = (token: string, oldPassword: string, newPassword: string): Promise<User> => {
  loadDb();
  const uid = token.replace('TOKEN_', '');
  const user = Object.values(db.users).find(u => u.uid === uid);
  if (!user) return apiError("Invalid user.");

  if (user.password !== oldPassword) {
    return apiError("Incorrect old password.");
  }
  
  if (newPassword.length < 8) {
      return apiError("New password must be at least 8 characters long.");
  }

  user.password = newPassword;
  saveDb();
  
  const { password: _, ...userToReturn } = user;
  return apiCall(userToReturn);
};

export const apiSetFundPassword = (token: string, currentPassword: string, newFundPassword: string): Promise<User> => {
  loadDb();
  const uid = token.replace('TOKEN_', '');
  const user = Object.values(db.users).find(u => u.uid === uid);
  if (!user) return apiError("Invalid user.");
  
  if (user.password !== currentPassword) {
      return apiError("Incorrect login password.");
  }
  
  if (newFundPassword.length < 6) {
      return apiError("Fund password must be at least 6 characters long.");
  }
  
  user.fundPassword = newFundPassword;
  saveDb();
  
  const { password: _, ...userToReturn } = user;
  return apiCall(userToReturn);
};

export const apiToggle2FA = (token: string, password: string, enable: boolean): Promise<User> => {
  loadDb();
  const uid = token.replace('TOKEN_', '');
  const user = Object.values(db.users).find(u => u.uid === uid);
  if (!user) return apiError("Invalid user.");
  
  if (user.password !== password) {
      return apiError("Incorrect password.");
  }
  
  user.is2FAEnabled = enable;
  saveDb();
  
  const { password: _, ...userToReturn } = user;
  return apiCall(userToReturn);
};