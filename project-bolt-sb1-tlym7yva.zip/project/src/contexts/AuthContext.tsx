import * as React from 'react';
import type { User, UserOrder, NewOrderData, UpdateOrderData, DepositData, SecondContractTrade, NewSecondContractData, WithdrawalData } from '../types.ts';
import { apiLogin, apiSignup, apiGetUserByToken, apiDeposit, apiApproveDeposit, apiPlaceOrder, apiCancelOrder, apiModifyOrder, apiPlaceSecondContractTrade, apiResolveSecondContracts, apiTransferFunds, apiExchangeAssets, apiSubmitIdentityDocs, apiApproveIdentity, apiWithdraw, apiApproveWithdrawal, apiChangePassword, apiSetFundPassword, apiToggle2FA } from '../server/api.ts';

const AUTH_TOKEN_KEY = 'cryptoPulseAuthToken';

interface SignupData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  country: string;
  birthDate: string;
  phone: string;
}

interface IdentityDocsData {
  idFrontFile: File;
  idBackFile: File;
  selfieFile: File;
}

interface AuthContextType {
  user: User | null;
  isLoggedIn: boolean;
  isInitialized: boolean; // Tracks if the initial session check is complete
  isLoading: boolean; // For specific actions like login/signup
  login: (email: string, password: string) => Promise<void>;
  signup: (data: SignupData) => Promise<void>;
  logout: () => void;
  deposit: (data: DepositData) => Promise<void>;
  approveDeposit: (transactionId: string) => Promise<void>;
  withdraw: (data: WithdrawalData) => Promise<void>;
  approveWithdrawal: (transactionId: string) => Promise<void>;
  updateUserPhoto: (photoFile: File) => Promise<void>;
  placeOrder: (order: NewOrderData) => Promise<UserOrder>;
  cancelOrder: (orderId: string) => Promise<UserOrder>;
  modifyOrder: (orderId: string, data: UpdateOrderData) => Promise<UserOrder>;
  placeSecondContractTrade: (tradeData: NewSecondContractData) => Promise<SecondContractTrade>;
  resolveSecondContracts: () => Promise<void>;
  transferFunds: (from: 'spot' | 'seconds', to: 'spot' | 'seconds', amount: number, asset: string) => Promise<void>;
  exchangeAssets: (fromAsset: string, toAsset: string, fromAmount: number) => Promise<void>;
  submitIdentityDocs: (data: IdentityDocsData) => Promise<void>;
  approveIdentity: () => Promise<void>;
  changePassword: (oldPassword: string, newPassword: string) => Promise<void>;
  setFundPassword: (currentPassword: string, newFundPassword: string) => Promise<void>;
  toggle2FA: (password: string, enable: boolean) => Promise<void>;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
}

const AuthContext = React.createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = React.useState<User | null>(null);
  const [token, setToken] = React.useState<string | null>(null);
  const [isInitialized, setIsInitialized] = React.useState<boolean>(false);
  const [isLoading, setIsLoading] = React.useState<boolean>(false);

  const rehydrateSession = React.useCallback(async () => {
    try {
      const storedToken = localStorage.getItem(AUTH_TOKEN_KEY);
      if (storedToken) {
        const fetchedUser = await apiGetUserByToken(storedToken);
        const storedPhoto = localStorage.getItem(`cryptoPulsePhoto-${fetchedUser.uid}`);
        if (storedPhoto) {
            fetchedUser.photoURL = storedPhoto;
        }
        setUser(fetchedUser);
        setToken(storedToken);
      }
    } catch (error) {
      console.error("Session rehydration failed:", error);
      localStorage.removeItem(AUTH_TOKEN_KEY);
    } finally {
      setIsInitialized(true);
    }
  }, []);

  React.useEffect(() => {
    rehydrateSession();
  }, [rehydrateSession]);
  
  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const { user: loggedInUser, token: new_token } = await apiLogin(email, password);
      const storedPhoto = localStorage.getItem(`cryptoPulsePhoto-${loggedInUser.uid}`);
      if (storedPhoto) {
          loggedInUser.photoURL = storedPhoto;
      }
      setUser(loggedInUser);
      setToken(new_token);
      localStorage.setItem(AUTH_TOKEN_KEY, new_token);
    } catch (error) {
       console.error("Login failed:", error);
       throw error; // re-throw to be caught in the component
    } finally {
      setIsLoading(false);
    }
  };
  
  const signup = async (data: SignupData) => {
    setIsLoading(true);
    try {
        const { user: signedUpUser, token: new_token } = await apiSignup(data);
        setUser(signedUpUser);
        setToken(new_token);
        localStorage.setItem(AUTH_TOKEN_KEY, new_token);
    } catch(error) {
        console.error("Signup failed:", error);
        throw error;
    } finally {
        setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem(AUTH_TOKEN_KEY);
  };
  
  const deposit = async (data: DepositData) => {
      if(!token) throw new Error("Not authenticated");
      setIsLoading(true);
      try {
          const screenshotURL = await new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.readAsDataURL(data.screenshotFile);
          });

          const updatedUser = await apiDeposit(token, { ...data, screenshotURL });
          
          const storedPhoto = localStorage.getItem(`cryptoPulsePhoto-${updatedUser.uid}`);
            if (storedPhoto) {
                updatedUser.photoURL = storedPhoto;
            }
          setUser(updatedUser);
      } catch (error) {
          console.error("Deposit failed:", error);
          throw error;
      } finally {
          setIsLoading(false);
      }
  };
  
  const approveDeposit = async (transactionId: string) => {
      if(!token) throw new Error("Not authenticated");
      try {
          const updatedUser = await apiApproveDeposit(token, transactionId);
          setUser(updatedUser);
      } catch (error) {
          console.error("Approval failed:", error);
          throw error;
      }
  };
  
  const withdraw = async (data: WithdrawalData) => {
      if(!token) throw new Error("Not authenticated");
      setIsLoading(true);
      try {
          const updatedUser = await apiWithdraw(token, data);
          const storedPhoto = localStorage.getItem(`cryptoPulsePhoto-${updatedUser.uid}`);
          if (storedPhoto) {
              updatedUser.photoURL = storedPhoto;
          }
          setUser(updatedUser);
      } catch (error) {
          console.error("Withdrawal failed:", error);
          throw error;
      } finally {
          setIsLoading(false);
      }
  };

  const approveWithdrawal = async (transactionId: string) => {
      if(!token) throw new Error("Not authenticated");
      try {
          const updatedUser = await apiApproveWithdrawal(token, transactionId);
          setUser(updatedUser);
      } catch (error) {
          console.error("Withdrawal approval failed:", error);
          throw error;
      }
  };

  const updateUserPhoto = (photoFile: File): Promise<void> => {
    return new Promise((resolve, reject) => {
      if (!user) {
        return reject(new Error("User not authenticated"));
      }
      const reader = new FileReader();
      reader.readAsDataURL(photoFile);
      reader.onload = () => {
        const dataUrl = reader.result as string;
        localStorage.setItem(`cryptoPulsePhoto-${user.uid}`, dataUrl);
        setUser(prevUser => (prevUser ? { ...prevUser, photoURL: dataUrl } : null));
        resolve();
      };
      reader.onerror = error => {
        reject(error);
      };
    });
  };

  const placeOrder = async (order: NewOrderData) => {
    if (!token) throw new Error("Not authenticated");
    const { user: updatedUser, newOrder } = await apiPlaceOrder(token, order);
    
    // update user state, but ensure we don't lose the photoURL loaded from localStorage
    const storedPhoto = localStorage.getItem(`cryptoPulsePhoto-${updatedUser.uid}`);
    if (storedPhoto) {
        updatedUser.photoURL = storedPhoto;
    }
    setUser(updatedUser);
    return newOrder;
  };

  const cancelOrder = async (orderId: string) => {
    if (!token) throw new Error("Not authenticated");
    const { user: updatedUser, cancelledOrder } = await apiCancelOrder(token, orderId);
    
    const storedPhoto = localStorage.getItem(`cryptoPulsePhoto-${updatedUser.uid}`);
    if (storedPhoto) {
        updatedUser.photoURL = storedPhoto;
    }
    setUser(updatedUser);
    return cancelledOrder;
  };

  const modifyOrder = async (orderId: string, data: UpdateOrderData) => {
    if (!token) throw new Error("Not authenticated");
    const { user: updatedUser, updatedOrder } = await apiModifyOrder(token, orderId, data);
    
    const storedPhoto = localStorage.getItem(`cryptoPulsePhoto-${updatedUser.uid}`);
    if (storedPhoto) {
        updatedUser.photoURL = storedPhoto;
    }
    setUser(updatedUser);
    return updatedOrder;
  };
  
  const placeSecondContractTrade = async (tradeData: NewSecondContractData) => {
    if (!token) throw new Error("Not authenticated");
    const { user: updatedUser, newTrade } = await apiPlaceSecondContractTrade(token, tradeData);
    
    const storedPhoto = localStorage.getItem(`cryptoPulsePhoto-${updatedUser.uid}`);
    if (storedPhoto) {
        updatedUser.photoURL = storedPhoto;
    }
    setUser(updatedUser);
    return newTrade;
  };

  const resolveSecondContracts = async () => {
    if (!token || !user) throw new Error("Not authenticated");
    // Only call API if there are active contracts to avoid unnecessary calls
    if (user.activeSecondContracts.some(t => new Date(t.closesAt) < new Date())) {
        try {
            const updatedUser = await apiResolveSecondContracts(token);
            const storedPhoto = localStorage.getItem(`cryptoPulsePhoto-${updatedUser.uid}`);
            if (storedPhoto) {
                updatedUser.photoURL = storedPhoto;
            }
            setUser(updatedUser);
        } catch (error) {
            console.error("Failed to resolve second contracts", error);
        }
    }
  }

  const transferFunds = async (from: 'spot' | 'seconds', to: 'spot' | 'seconds', amount: number, asset: string) => {
    if (!token) throw new Error("Not authenticated");
    setIsLoading(true);
    try {
        const updatedUser = await apiTransferFunds(token, from, to, amount, asset);
        const storedPhoto = localStorage.getItem(`cryptoPulsePhoto-${updatedUser.uid}`);
        if (storedPhoto) {
            updatedUser.photoURL = storedPhoto;
        }
        setUser(updatedUser);
    } catch (error) {
        console.error("Transfer failed:", error);
        throw error;
    } finally {
        setIsLoading(false);
    }
  };
  
  const exchangeAssets = async (fromAsset: string, toAsset: string, fromAmount: number) => {
    if (!token) throw new Error("Not authenticated");
    setIsLoading(true);
    try {
        const updatedUser = await apiExchangeAssets(token, fromAsset, toAsset, fromAmount);
        const storedPhoto = localStorage.getItem(`cryptoPulsePhoto-${updatedUser.uid}`);
        if (storedPhoto) {
            updatedUser.photoURL = storedPhoto;
        }
        setUser(updatedUser);
    } catch (error) {
        console.error("Exchange failed:", error);
        throw error;
    } finally {
        setIsLoading(false);
    }
  };
  
  const submitIdentityDocs = async (data: IdentityDocsData) => {
      if(!token) throw new Error("Not authenticated");
      setIsLoading(true);
      try {
          const [idFrontUrl, idBackUrl, selfieUrl] = await Promise.all([
              new Promise<string>((resolve) => {
                  const reader = new FileReader();
                  reader.onload = () => resolve(reader.result as string);
                  reader.readAsDataURL(data.idFrontFile);
              }),
              new Promise<string>((resolve) => {
                  const reader = new FileReader();
                  reader.onload = () => resolve(reader.result as string);
                  reader.readAsDataURL(data.idBackFile);
              }),
              new Promise<string>((resolve) => {
                  const reader = new FileReader();
                  reader.onload = () => resolve(reader.result as string);
                  reader.readAsDataURL(data.selfieFile);
              }),
          ]);
          
          const updatedUser = await apiSubmitIdentityDocs(token, { idFrontUrl, idBackUrl, selfieUrl });
          
          const storedPhoto = localStorage.getItem(`cryptoPulsePhoto-${updatedUser.uid}`);
          if (storedPhoto) {
              updatedUser.photoURL = storedPhoto;
          }
          setUser(updatedUser);
      } catch (error) {
          console.error("Identity submission failed:", error);
          throw error;
      } finally {
          setIsLoading(false);
      }
  };

  const approveIdentity = async () => {
      if(!token) throw new Error("Not authenticated");
      try {
          const updatedUser = await apiApproveIdentity(token);
          const storedPhoto = localStorage.getItem(`cryptoPulsePhoto-${updatedUser.uid}`);
          if (storedPhoto) {
              updatedUser.photoURL = storedPhoto;
          }
          setUser(updatedUser);
      } catch (error) {
          console.error("Identity approval failed:", error);
          throw error;
      }
  };

  const changePassword = async (oldPassword: string, newPassword: string) => {
    if (!token) throw new Error("Not authenticated");
    const updatedUser = await apiChangePassword(token, oldPassword, newPassword);
    setUser(prev => prev ? { ...updatedUser, photoURL: prev.photoURL } : updatedUser);
  };

  const setFundPassword = async (currentPassword: string, newFundPassword: string) => {
    if (!token) throw new Error("Not authenticated");
    const updatedUser = await apiSetFundPassword(token, currentPassword, newFundPassword);
    setUser(prev => prev ? { ...updatedUser, photoURL: prev.photoURL } : updatedUser);
  };
  
  const toggle2FA = async (password: string, enable: boolean) => {
    if (!token) throw new Error("Not authenticated");
    const updatedUser = await apiToggle2FA(token, password, enable);
    setUser(prev => prev ? { ...updatedUser, photoURL: prev.photoURL } : updatedUser);
  };


  const value = {
    user,
    isLoggedIn: !!user,
    isInitialized,
    isLoading,
    login,
    signup,
    logout,
    deposit,
    approveDeposit,
    withdraw,
    approveWithdrawal,
    updateUserPhoto,
    placeOrder,
    cancelOrder,
    modifyOrder,
    placeSecondContractTrade,
    resolveSecondContracts,
    transferFunds,
    exchangeAssets,
    submitIdentityDocs,
    approveIdentity,
    changePassword,
    setFundPassword,
    toggle2FA,
    setUser,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = React.useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};